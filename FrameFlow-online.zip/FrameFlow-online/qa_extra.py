"""Independent adversarial regression checks; never uses the live data directory."""
from __future__ import annotations

import contextlib
import csv
import hashlib
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("frameflow_snapshot", ROOT / "scripts" / "backup.py")
snapshot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(snapshot)


class APIClient:
    def __init__(self, port):
        self.port, self.cookie, self.csrf = port, "", ""

    def request(self, path, data=None, method=None, headers=None, raw=None, csrf=True):
        supplied = {"Cookie": self.cookie}
        if data is not None:
            raw = json.dumps(data).encode()
            supplied["Content-Type"] = "application/json"
        if csrf:
            supplied["X-CSRF-Token"] = self.csrf
        supplied.update(headers or {})
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            connection.request(method or ("POST" if raw is not None else "GET"), path, body=raw, headers=supplied)
            response = connection.getresponse()
            content = response.read()
            result = (response.status, dict(response.getheaders()), content)
            if response.getheader("Set-Cookie"):
                self.cookie = response.getheader("Set-Cookie").split(";", 1)[0]
            if response.getheader("Content-Type", "").startswith("application/json"):
                value = json.loads(content)
                if response.status == 200 and value.get("csrf"):
                    self.csrf = value["csrf"]
            return result
        finally:
            connection.close()

    def json(self, path, data=None, **kwargs):
        status, headers, content = self.request(path, data, **kwargs)
        return status, json.loads(content)


class APISafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="frameflow-api-qa-")
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            cls.port = listener.getsockname()[1]
        cls.log = tempfile.TemporaryFile()
        cls.process = subprocess.Popen([sys.executable, str(ROOT / "server.py")], cwd=ROOT,
            env={**os.environ, "VIDEOQA_DATA": cls.temp.name, "HOST": "127.0.0.1", "PORT": str(cls.port), "VIDEOQA_ORIGIN": "", "SECURE_COOKIES": "0"},
            stdout=cls.log, stderr=cls.log)
        cls.admin, cls.guest = APIClient(cls.port), APIClient(cls.port)
        for _ in range(100):
            try:
                if cls.guest.json("/api/health")[0] == 200:
                    break
            except (OSError, http.client.HTTPException):
                time.sleep(.03)
        else:
            raise RuntimeError("QA server failed to become ready")
        status, user = cls.admin.json("/api/register", {"name": "QA Admin", "email": "qa-admin@example.com", "password": "QA-password-123!"})
        if status != 200:
            raise RuntimeError(f"QA bootstrap failed: {status}")
        cls.admin_id = user["user"]["id"]

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        cls.process.wait(timeout=5)
        cls.log.close()
        cls.temp.cleanup()

    def make_reviewer(self, suffix):
        status, invite = self.admin.json("/api/invites", {"role": "reviewer"})
        self.assertEqual(status, 200)
        client = APIClient(self.port)
        status, data = client.json("/api/register", {"name": "QA " + suffix, "email": suffix + "@example.com", "password": "QA-password-123!", "invite_code": invite["code"], "role": "admin"})
        self.assertEqual(status, 200)
        self.assertEqual(data["user"]["role"], "reviewer")
        return client, data["user"]["id"]

    def make_task(self, **overrides):
        status, result = self.admin.json("/api/tasks", {"title": self._testMethodName, "kind": "aigc", "url": "https://example.com/clip.mp4", **overrides})
        self.assertEqual(status, 200)
        return result["id"]

    def test_guest_cannot_read_workspace_or_admin_exports(self):
        status, state = self.guest.json("/api/state")
        self.assertEqual(status, 200)
        self.assertIsNone(state["user"])
        self.assertEqual([state[k] for k in ("tasks", "reviews", "users")], [[], [], []])
        for path in ("/api/backup", "/api/audit"):
            self.assertEqual(self.guest.json(path)[0], 401)

    def test_csrf_and_cross_site_write_rejection(self):
        data = {"title": "forbidden", "kind": "material"}
        self.assertEqual(self.admin.json("/api/tasks", data, csrf=False)[0], 403)
        self.assertEqual(self.admin.json("/api/tasks", data, headers={"Origin": "https://attacker.invalid"})[0], 403)
        self.assertEqual(self.admin.json("/api/tasks", data, headers={"Sec-Fetch-Site": "cross-site"})[0], 403)
        self.assertEqual(self.guest.json("/api/login", {"email": "qa-admin@example.com", "password": "QA-password-123!"}, headers={"Origin": "https://attacker.invalid"})[0], 403)

    def test_reviewer_cannot_escalate_role_or_change_other_task(self):
        client, uid = self.make_reviewer("qa-permissions")
        tid = self.make_task()
        for path, body in (("/api/invites", {"role": "admin"}), ("/api/members", {"user_id": uid, "role": "admin"}), ("/api/tasks/" + str(tid), {"title": "stolen"}), ("/api/restore", {"mode": "replace", "backup": {}})):
            self.assertEqual(client.json(path, body)[0], 403)
        self.assertEqual(client.json("/api/backup")[0], 403)
        self.assertEqual(client.json("/api/audit")[0], 403)

    def test_disabled_member_session_and_logout_cookie_are_revoked(self):
        client, uid = self.make_reviewer("qa-disable")
        old_cookie = client.cookie
        self.assertEqual(self.admin.json("/api/members", {"user_id": uid, "active": False})[0], 200)
        self.assertIsNone(client.json("/api/state")[1]["user"])
        self.assertEqual(client.json("/api/tasks", {"title": "forbidden", "kind": "material"})[0], 401)
        client, uid = self.make_reviewer("qa-logout")
        old_cookie = client.cookie
        self.assertEqual(client.json("/api/logout", {})[0], 200)
        client.cookie = old_cookie
        self.assertIsNone(client.json("/api/state")[1]["user"])
        self.assertEqual(self.admin.json("/api/members", {"user_id": self.admin_id, "role": "reviewer"})[0], 409)

    def test_json_shape_nonfinite_and_huge_integer_validation(self):
        for content in (b"[]", b"null", b"true", b'{"title":NaN}', b'{"title":Infinity}', b"{"):
            with self.subTest(content=content):
                status, _, _ = self.admin.request("/api/tasks", raw=content, headers={"Content-Type": "application/json"})
                self.assertEqual(status, 400)
        for value in (True, -1, 2**100, "1", []):
            with self.subTest(id=value):
                status, _ = self.admin.json("/api/reviews", {"task_id": value, "scores": [4] * 5, "verdict": "通过"})
                self.assertEqual(status, 400)
        self.assertEqual(self.admin.json("/api/tasks/" + "9" * 5000, {"title": "invalid"})[0], 400)

    def test_invalid_and_missing_media_scores_rejected(self):
        tid = self.make_task(url="")
        self.assertEqual(self.admin.json("/api/reviews", {"task_id": tid, "scores": [4]*5, "verdict": "通过"})[0], 400)
        tid = self.make_task()
        for scores in ([True]*5, [0]*5, [6]*5, [4]*4, "44444", [None]*5):
            self.assertEqual(self.admin.json("/api/reviews", {"task_id": tid, "scores": scores, "verdict": "通过"})[0], 400)
        self.assertEqual(self.admin.json("/api/reviews", {"task_id": tid, "scores": [2]*5, "verdict": "退回", "note": ""})[0], 400)

    def test_media_authorization_ranges_and_paths(self):
        media = b"\x00\x00\x00\x18ftypmp42" + bytes(range(128))
        status, _, content = self.admin.request("/api/upload", raw=media, headers={"Content-Type": "video/mp4", "X-Filename": "clip.mp4"})
        self.assertEqual(status, 200)
        path = json.loads(content)["url"]
        self.assertEqual(self.guest.request(path)[0], 401)
        for value, expected in (("bytes=0-9", media[:10]), ("bytes=-9", media[-9:]), ("bytes=100-", media[100:]), ("bytes=0-999999", media)):
            status, headers, payload = self.admin.request(path, headers={"Range": value})
            self.assertEqual(status, 206)
            self.assertEqual(payload, expected)
            self.assertIn("Content-Range", headers)
        for value in ("bytes=-0", "bytes=9999-", "bytes=10-3", "bytes=0-3,10-20", "bytes=" + "9"*5000 + "-"):
            self.assertEqual(self.admin.request(path, headers={"Range": value})[0], 416)
        status, headers, payload = self.admin.request(path, method="HEAD")
        self.assertEqual(status, 200)
        self.assertEqual(payload, b"")
        self.assertEqual(int(headers["Content-Length"]), len(media))
        for path in ("/media/../../server.py", "/%2e%2e/server.py", "/.git/config"):
            self.assertEqual(self.admin.request(path)[0], 404)

    def test_restore_malformed_backup_rolls_back(self):
        self.make_task()
        _, original = self.admin.json("/api/backup")
        for field, value in (("status", []), ("status", {}), ("created_by", {}), ("id", 2**100), ("assignee", True), ("created_at", '<img src=x onerror=alert(1)>')):
            backup = json.loads(json.dumps(original))
            backup["tasks"][0][field] = value
            with self.subTest(field=field, value=value):
                self.assertEqual(self.admin.json("/api/restore", {"mode": "replace", "backup": backup})[0], 400)
                _, state = self.admin.json("/api/state")
                self.assertEqual(state["tasks"], original["tasks"])
                self.assertEqual(state["reviews"], original["reviews"])

    def test_admin_resolution_survives_restore_and_stays_locked(self):
        tid = self.make_task()
        reviewer, _ = self.make_reviewer("qa-resolution")
        scores = {"task_id": tid, "scores": [4]*5, "verdict": "通过"}
        self.assertEqual(self.admin.json("/api/reviews", scores)[0], 200)
        self.assertEqual(self.admin.json(f"/api/tasks/{tid}/resolve", {"verdict": "通过", "note": "need two independent reviews"})[0], 400)
        self.assertEqual(reviewer.json("/api/reviews", {**scores, "scores": [2]*5, "verdict": "退回", "note": "形体崩坏"})[0], 200)
        self.assertEqual(reviewer.json(f"/api/tasks/{tid}/resolve", {"verdict": "通过", "note": "forbidden"})[0], 403)
        self.assertEqual(self.admin.json(f"/api/tasks/{tid}/resolve", {"verdict": "通过", "note": "用途允许轻微形变，裁定通过"})[0], 200)
        _, backup = self.admin.json("/api/backup")
        self.assertEqual(self.admin.json("/api/restore", {"mode": "replace", "backup": backup})[0], 200)
        task = next(t for t in self.admin.json("/api/state")[1]["tasks"] if t["id"] == tid)
        self.assertEqual(task["status"], "已通过")
        self.assertEqual(task["resolution_verdict"], "通过")
        self.assertEqual(task["resolution_by"], self.admin_id)
        self.assertEqual(task["resolution_note"], "用途允许轻微形变，裁定通过")
        self.assertEqual(reviewer.json("/api/reviews", scores)[0], 409)

    def raw_http(self, content):
        with socket.create_connection(("127.0.0.1", self.port), timeout=5) as connection:
            connection.sendall(content)
            response = bytearray()
            while True:
                piece = connection.recv(65536)
                if not piece:
                    return bytes(response)
                response.extend(piece)

    def test_rejected_bodies_do_not_become_keepalive_requests(self):
        nested = b"GET /api/health HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n"
        for path, extra, expected in (("/api/upload", b"Content-Type: video/mp4\r\n", b"401"), ("/api/tasks", b"Content-Type: application/json\r\nOrigin: https://attacker.invalid\r\n", b"403")):
            with self.subTest(path=path):
                response = self.raw_http(b"POST " + path.encode() + b" HTTP/1.1\r\nHost: localhost\r\n" + extra + b"Content-Length: " + str(len(nested)).encode() + b"\r\n\r\n" + nested)
                self.assertTrue(response.startswith(b"HTTP/1.1 " + expected), response[:80])
                self.assertEqual(response.count(b"HTTP/1.1 "), 1)
                self.assertNotIn(b'"service":"FrameFlow"', response)

    def test_ambiguous_or_unbounded_request_lengths_are_rejected(self):
        for header, expected in ((b"Content-Length: 2\r\nContent-Length: 2\r\n", b"400"), (b"Transfer-Encoding: chunked\r\n", b"400"), (b"Content-Length: " + b"9" * 5000 + b"\r\n", b"413")):
            with self.subTest(header=header[:50]):
                response = self.raw_http(b"POST /api/login HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\n" + header + b"\r\n{}")
                self.assertTrue(response.startswith(b"HTTP/1.1 " + expected), response[:80])
        response = self.raw_http(b"GET http://[invalid HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
        self.assertTrue(response.startswith(b"HTTP/1.1 400"), response[:80])


class SnapshotSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="frameflow-qa-")
        self.root = Path(self.temp.name)
        self.data = self.root / "data"
        self.data.mkdir()
        with sqlite3.connect(self.data / "videoqa.db") as db:
            db.executescript("CREATE TABLE sessions(token TEXT); INSERT INTO sessions VALUES('test-session'); CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT);")
            db.execute("INSERT INTO tasks VALUES(1,?)", ("评测数据",))
        (self.data / "uploads").mkdir()
        (self.data / "uploads" / "clip.mp4").write_bytes(b"test-media-contents")
        self.archive = self.root / "backup.tar.gz"

    def tearDown(self):
        self.temp.cleanup()

    def backup(self):
        with contextlib.redirect_stdout(io.StringIO()):
            snapshot.backup(self.data, self.archive)

    def restore(self, archive=None):
        target = self.root / "restored"
        with contextlib.redirect_stdout(io.StringIO()):
            snapshot.restore(archive or self.archive, target)
        return target

    def tar(self, name, items):
        archive = self.root / name
        with tarfile.open(archive, "w:gz") as tar:
            for path, content, special in items:
                item = tarfile.TarInfo(path)
                if special:
                    item.type = tarfile.SYMTYPE
                    item.linkname = "/etc/passwd"
                else:
                    item.size = len(content)
                tar.addfile(item, None if special else io.BytesIO(content))
        return archive

    def test_consistent_snapshot_restores_data_and_revokes_sessions(self):
        self.backup()
        self.assertEqual(self.archive.stat().st_mode & 0o777, 0o600)
        target = self.restore()
        self.assertEqual((target / "uploads" / "clip.mp4").read_bytes(), b"test-media-contents")
        with sqlite3.connect(target / "videoqa.db") as db:
            self.assertEqual(db.execute("SELECT title FROM tasks").fetchone()[0], "评测数据")
            self.assertEqual(db.execute("SELECT count(*) FROM sessions").fetchone()[0], 0)

    def test_backup_refuses_overwrite_and_nested_destination(self):
        self.backup()
        original = self.archive.read_bytes()
        with self.assertRaises(ValueError):
            self.backup()
        self.assertEqual(self.archive.read_bytes(), original)
        with self.assertRaises(ValueError):
            snapshot.backup(self.data, self.data / "nested.tar.gz")

    def test_restore_refuses_existing_directory(self):
        self.backup()
        target = self.root / "existing"
        target.mkdir()
        (target / "preserve.txt").write_text("user data")
        with self.assertRaises(ValueError):
            snapshot.restore(self.archive, target)
        self.assertEqual((target / "preserve.txt").read_text(), "user data")

    def test_restore_rejects_unsafe_paths_duplicates_and_symlinks(self):
        for i, items in enumerate([
            [("../escape", b"x", False)],
            [("/tmp/escape", b"x", False)],
            [("uploads/clip.mp4", b"x", True)],
            [("duplicate", b"a", False), ("duplicate", b"b", False)],
        ]):
            with self.subTest(items=items):
                archive = self.tar(f"malicious-{i}.tgz", items)
                with self.assertRaises(ValueError):
                    self.restore(archive)
                self.assertFalse((self.root / "restored").exists())
        self.assertFalse((self.root / "escape").exists())

    def test_restore_rejects_tampered_contents(self):
        manifest = json.dumps({"format": "frameflow-server-snapshot-v1", "files": {"videoqa.db": hashlib.sha256(b"original").hexdigest()}}).encode()
        archive = self.tar("tampered.tgz", [("videoqa.db", b"tampered", False), ("snapshot-manifest.json", manifest, False)])
        with self.assertRaises(ValueError):
            self.restore(archive)
        self.assertFalse((self.root / "restored").exists())

    def test_backup_refuses_symlink_data(self):
        (self.data / "uploads" / "external.mp4").symlink_to(self.root / "outside")
        with self.assertRaises(ValueError):
            self.backup()


if __name__ == "__main__":
    if "--browser" not in sys.argv:
        unittest.main(verbosity=2)
    else:
        # Optional integration check; Python Playwright and system Chromium required.
        from playwright.sync_api import sync_playwright
        APISafetyTests.setUpClass()
        try:
            admin = APISafetyTests.admin
            status, created = admin.json("/api/tasks", {"title": 'QA <img src=x onerror="window.__qaXSS=1">', "kind": "material", "url": "https://example.com/qa.mp4", "category": "QA", "duration": "00:01", "description": '<svg onload="window.__qaXSS=2"></svg>'})
            assert status == 200
            task_id = created["id"]
            assert admin.json("/api/reviews", {"task_id": task_id, "scores": [3]*5, "verdict": "需复核", "note": '<img src=x onerror="window.__qaXSS=3">'})[0] == 200
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=os.environ.get("CHROMIUM_PATH", "/usr/bin/chromium"), headless=True, args=["--no-sandbox"])
                try:
                    context = browser.new_context()
                    base = f"http://127.0.0.1:{APISafetyTests.port}"
                    context.add_cookies([{"name": "session", "value": admin.cookie.split("=", 1)[1], "url": base, "httpOnly": True, "sameSite": "Strict"}])
                    page = context.new_page()
                    page.route("https://example.com/**", lambda route: route.abort())
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.on("dialog", lambda dialog: dialog.accept())
                    page.goto(base)
                    page.wait_for_function("() => state.user && connection === 'ready'")
                    for screen in ("overview", "material", "cases"):
                        page.evaluate("screen => go(screen)", screen)
                        assert page.locator("[onerror],[onload]").count() == 0
                        assert page.evaluate("window.__qaXSS") is None
                    page.evaluate("id => reviewModal(id)", task_id)
                    assert page.locator("[onerror],[onload]").count() == 0
                    assert page.evaluate("window.__qaXSS") is None
                    fallback = page.evaluate("timeText('<img src=x onerror=alert(1)>')")
                    assert "<" not in fallback and ">" not in fallback, "Invalid dates returned unsafe HTML"
                    page.locator("#delete-task").click()
                    page.wait_for_function("id => !state.tasks.some(task => task.id === id)", arg=task_id)
                    assert page.locator(".modal").count() == 0
                    status, _ = admin.json("/api/tasks", {"title": "=2+2", "kind": "material", "url": "https://example.com/qa.mp4"})
                    assert status == 200
                    page.evaluate("async title => { await refresh(); go('overview'); state.tasks[0].title=title; }", "\t =2+2")
                    with page.expect_download() as download:
                        page.locator("#export").click()
                    with open(download.value.path(), encoding="utf-8-sig", newline="") as exported:
                        rows = list(csv.reader(exported))
                    assert rows[1][1].startswith("'\t =2+2"), "Leading-control spreadsheet formula was not neutralized"
                    # A stale editor must preserve a newer teammate update.
                    page.evaluate("async () => { await refresh(); createModal(state.tasks[0]); }")
                    live_task = admin.json("/api/state")[1]["tasks"][0]
                    assert admin.json(f"/api/tasks/{live_task['id']}", {"title": "Newer teammate edit"})[0] == 200
                    page.locator('#create-form [name="title"]').fill("Stale browser edit")
                    page.locator('#create-form button[type="submit"]').click()
                    page.locator(".form-error").wait_for()
                    assert "其他成员" in page.locator(".form-error").inner_text()
                    assert admin.json("/api/state")[1]["tasks"][0]["title"] == "Newer teammate edit"
                    page.keyboard.press("Escape")
                    # Exercise the UI string-to-bool conversion for account disable.
                    status, invite = admin.json("/api/invites", {"role": "reviewer"})
                    assert status == 200
                    member = APIClient(APISafetyTests.port)
                    status, registered = member.json("/api/register", {"name": "QA browser member", "email": "qa-browser-member@example.com", "password": "QA-password-123!", "invite_code": invite["code"]})
                    assert status == 200
                    uid = registered["user"]["id"]
                    page.evaluate("async uid => { await refresh(); go('team'); memberModal(uid); }", uid)
                    page.locator('#member-form [name="active"]').select_option("0")
                    page.locator('#member-form button[type="submit"]').click()
                    page.wait_for_function("() => !document.querySelector('.modal')")
                    assert member.json("/api/state")[1]["user"] is None
                    page.set_viewport_size({"width": 390, "height": 844})
                    for screen in ("overview", "material", "aigc", "analytics", "standards", "cases", "team", "settings"):
                        page.evaluate("screen => go(screen)", screen)
                        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1"), f"Mobile horizontal overflow: {screen}"
                    page.evaluate("id => reviewModal(id)", live_task["id"])
                    assert page.evaluate("document.querySelector('.modal').scrollWidth <= document.querySelector('.modal').clientWidth + 1"), "Mobile review dialog overflow"
                    page.keyboard.press("Escape")
                    assert errors == [], errors
                    print("PASS browser security integration: HTML escaping, invalid-date fallback, actual DELETE, CSV formula neutralization, stale-edit conflict, account disable, 8 mobile pages + review dialog without horizontal overflow; no page errors.")
                finally:
                    browser.close()
        finally:
            APISafetyTests.tearDownClass()
