"""Optional real-container HTTPS acceptance. Requires Docker, prebuilt frameflow:acceptance image."""
import http.cookiejar,json,os,socket,ssl,subprocess,tempfile,time,uuid
from pathlib import Path
import urllib.request,urllib.error

def docker(*args):
    result=subprocess.run(['docker',*args],check=True,text=True,capture_output=True)
    return result.stdout.strip()

def main():
    suffix=uuid.uuid4().hex[:10];network='ff-test-'+suffix;app='ff-app-'+suffix;gateway='ff-tls-'+suffix
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    origin='https://localhost:'+str(port)
    names=[]
    with tempfile.TemporaryDirectory(prefix='frameflow-deploy-') as directory:
        directory=Path(directory);config=directory/'Caddyfile';config.write_text('https://localhost {\n tls internal\n reverse_proxy app:3000\n}\n')
        try:
            docker('network','create',network)
            docker('run','-d','--name',app,'--network',network,'--network-alias','app','--read-only','--tmpfs','/tmp:size=64m','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','128','-e','SECURE_COOKIES=1','-e','VIDEOQA_ORIGIN='+origin,'frameflow:acceptance');names.append(app)
            docker('run','-d','--name',gateway,'--network',network,'-e','NO_PROXY=app,localhost,127.0.0.1','-e','no_proxy=app,localhost,127.0.0.1','-p',f'127.0.0.1:{port}:443','--mount',f'type=bind,src={config},dst=/etc/caddy/Caddyfile,readonly','caddy:2.10.2-alpine');names.append(gateway)
            cert=directory/'root.crt'
            for _ in range(50):
                try:docker('cp',gateway+':/data/caddy/pki/authorities/local/root.crt',str(cert));break
                except subprocess.CalledProcessError:time.sleep(.1)
            assert cert.exists(),'Caddy root CA not generated'
            # Test connects exclusively to this host's loopback listener, never to egress destinations.
            context=ssl.create_default_context(cafile=str(cert));jar=http.cookiejar.CookieJar()
            client=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context),urllib.request.HTTPCookieProcessor(jar))
            def request(path,data=None,csrf=None):
                headers={'Content-Type':'application/json'}
                if csrf:headers['X-CSRF-Token']=csrf
                r=urllib.request.Request(origin+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
                try:
                    with client.open(r,timeout=10) as response:return json.load(response),response.headers
                except urllib.error.HTTPError as e:
                    raise RuntimeError(f'HTTP {e.code}: {e.read().decode()}') from e
            for _ in range(50):
                try:assert request('/api/health')[0]['ok'];break
                except (urllib.error.URLError,RuntimeError):time.sleep(.1)
            _,headers=request('/api/register',{'name':'TLS Test','email':'tls-test@example.com','password':'test-TLS-password-123'})
            cookie=headers['Set-Cookie'];assert 'Secure' in cookie and 'HttpOnly' in cookie and 'SameSite=Strict' in cookie
            state,_=request('/api/state');assert state['user']['role']=='admin';csrf=state['csrf']
            request('/api/tasks',{'title':'TLS persistent task','kind':'material','url':'https://example.com/video.mp4'},csrf)
            assert docker('exec',app,'id','-u')=='10001'
            docker('restart',app)
            for _ in range(50):
                try:
                    state,_=request('/api/state')
                    if state['tasks']:break
                except (urllib.error.URLError,RuntimeError):pass
                time.sleep(.1)
            assert state['tasks'][0]['title']=='TLS persistent task'
            with client.open(origin+'/',timeout=10) as response:
                assert response.headers.get('Content-Security-Policy')
                assert 'FrameFlow' in response.read().decode()
            print('PASS: verified TLS CA, secure session cookie, CSRF write, nonroot read-only container, restart persistence')
        finally:
            for name in reversed(names):
                try:docker('rm','-f','-v',name)
                except subprocess.CalledProcessError:pass
            try:docker('network','rm',network)
            except subprocess.CalledProcessError:pass

if __name__=='__main__':main()
