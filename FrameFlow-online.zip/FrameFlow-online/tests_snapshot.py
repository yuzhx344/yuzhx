import importlib.util,sqlite3,tempfile,tarfile,io,json,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('snap',Path(__file__).parent/'scripts'/'backup.py');snap=importlib.util.module_from_spec(spec);spec.loader.exec_module(snap)
class Snapshots(unittest.TestCase):
 def test_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);src=d/'data';src.mkdir();(src/'uploads').mkdir();(src/'uploads'/'clip.mp4').write_bytes(b'video')
   with sqlite3.connect(src/'videoqa.db') as c:c.executescript("CREATE TABLE sessions(token TEXT); INSERT INTO sessions VALUES ('old-session'); CREATE TABLE tasks(id INTEGER); INSERT INTO tasks VALUES(9);")
   snap.backup(src,d/'backup.tgz');self.assertEqual((d/'backup.tgz').stat().st_mode & 0o777,0o600);snap.restore(d/'backup.tgz',d/'restored')
   self.assertEqual((d/'restored'/'uploads'/'clip.mp4').read_bytes(),b'video')
   with sqlite3.connect(d/'restored'/'videoqa.db') as c:
    self.assertEqual(c.execute('SELECT id FROM tasks').fetchone()[0],9);self.assertEqual(c.execute('SELECT count(*) FROM sessions').fetchone()[0],0)
   with self.assertRaises(ValueError):snap.restore(d/'backup.tgz',d/'restored')
 def test_traversal(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d)
   with tarfile.open(d/'bad.tgz','w:gz') as t:
    m=tarfile.TarInfo('../escape');m.size=4;t.addfile(m,io.BytesIO(b'evil'))
   with self.assertRaises(ValueError):snap.restore(d/'bad.tgz',d/'restored')
   self.assertFalse((d/'escape').exists());self.assertFalse((d/'restored').exists())
 def test_symlink(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);src=d/'data';src.mkdir()
   with sqlite3.connect(src/'videoqa.db') as c:c.execute('CREATE TABLE tasks(id INTEGER)')
   (src/'link').symlink_to('/etc/passwd')
   with self.assertRaises(ValueError):snap.backup(src,d/'backup.tgz')
 def test_checksum_failure(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d)
   with tarfile.open(d/'bad.tgz','w:gz') as t:
    for name,body in [('videoqa.db',b'bad database'),('snapshot-manifest.json',json.dumps({'format':'frameflow-server-snapshot-v1','files':{'videoqa.db':'wrong'}}).encode())]:
     m=tarfile.TarInfo(name);m.size=len(body);t.addfile(m,io.BytesIO(body))
   with self.assertRaises(ValueError):snap.restore(d/'bad.tgz',d/'restored')
   self.assertFalse((d/'restored').exists())
if __name__=='__main__':unittest.main()
