"""Compatibility entry point for all isolated Python regression tests."""
import unittest
if __name__=='__main__':
 suite=unittest.TestSuite()
 loader=unittest.TestLoader()
 for name in ['tests_backend','tests_snapshot','tests_manage','qa_extra']:
  suite.addTests(loader.loadTestsFromName(name))
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 raise SystemExit(0 if result.wasSuccessful() else 1)
