# 帧序 FrameFlow · 视频质量协作平台

针对「已有视频素材」与「AIGC 生成视频」的中文质量评测工作台。交付在线部署包与单文件离线版，不依赖在线字体、图片或前端 CDN。

## 交付物

- `artifacts/FrameFlow-online.zip`：应用源码、部署配置、测试、操作与备份说明。
- `offline/帧序-离线视频评测.html`：双击打开的独立网页。
- `offline/FrameFlow-offline.zip`：离线 HTML 与使用说明。
- `验收报告.md`：实际执行的测试、已修复问题及验收范围。

在线版适合部署在单个公司团队的服务器上；离线版适合单机评测、培训和演示，不支持跨电脑实时协作。此项目没有代为发布公网，也没有连接公司的真实身份、视频库或生产数据库。

## 本机运行在线版

要求 Python 3.12+，运行应用不需要安装第三方 Python 包。

```sh
python3 server.py
```

默认监听本机端口 3000。使用浏览器访问运行机器的该端口。首个注册账号为管理员，之后由管理员生成邀请码供成员注册。首次部署请先完成管理员初始化，再向团队开放访问。

开发测试可设置：

```sh
HOST=0.0.0.0 PORT=3000 VIDEOQA_DATA=/absolute/path/to/private-data python3 server.py
```

`VIDEOQA_DATA` 默认是仓库下 `.data`。其中数据库、上传素材及日志相关数据应持久化，不能放在公开静态网站目录。开发模式的 HTTP 用于本机验收；公司访问应使用下方 HTTPS 部署。

## 公司服务器 HTTPS 部署

需要一台已安装 Docker Engine 和 Compose v2 的 Linux 服务器，一个已指向该服务器的域名，并允许 80/443 入站。

```sh
cp deploy/.env.example deploy/.env
# 编辑 deploy/.env，填写真实 DOMAIN 和 ACME_EMAIL
# 示例域名和邮箱不能直接用于生产部署。
docker compose --env-file deploy/.env -f deploy/compose.yaml up -d --build
docker compose --env-file deploy/.env -f deploy/compose.yaml ps
```

Caddy 会申请 TLS 证书并将 HTTP 重定向到 HTTPS。应用不直接映射公网端口；通过 Caddy 访问。配置包含持久化卷、健康检查、非 root 应用进程、只读应用文件系统、资源限制和日志轮转。默认上限为单视频 200 MiB、同时 4 个上传、总素材 10 GiB（可通过 VIDEOQA_STORAGE_LIMIT_BYTES 调整），网关请求上限 210 MB；还受可用磁盘与上传时间影响。删除任务会保留其上传素材，取消创建后已上传的文件也可能占用配额；上线应按公司留存策略定期处理无引用素材，当前不提供自动媒体清理。

没有自动创建证书的内网域名可由公司网关终止 TLS，替换 `deploy/Caddyfile` 并保持原始 Host 与 Origin 一致；设置 `SECURE_COOKIES=1`、`VIDEOQA_ORIGIN=https://真实域名`。证书、DNS、SSO 及服务器防火墙由公司的运维策略决定，交付包不包含这些外部资源。

应用数据库基于 SQLite，面向单实例、单团队部署。不要启动多个应用副本共享同一 SQLite 文件，也不要把数据库放在不支持 SQLite 锁语义的网络盘上。高并发、大型素材库、多组织隔离应另行迁移数据库和对象存储。

## 数据与评测规则

- 视频支持上传本机 MP4 / WebM / MOV，或使用浏览器可访问的视频直链。编码是否能播放取决于浏览器支持，文件格式校验不能保证编码兼容。
- 素材和 AIGC 任务分别组织；生成任务可以保存提示词、模型、版本与来源等信息。
- 评分围绕清晰度、美学、动态连贯性、音频质量与内容完整性；问题可附具体时间点和说明。
- 多人独立评分；一致结论和分歧按系统规则流转。CSV 导出包含真实任务与评分，统计不虚构金标准确率或召回率。
- 质量标准提供可执行的分级参考。不同业务对静音素材、片长、构图等有不同要求，正式执行前应通过实际样本校准。
- 初始示例必须标为演示素材；没有视频的示例不能提交正式评分。正式上线可删除示例，从真实视频开始。

## 备份和恢复

页面 JSON 备份和完整服务器快照是两种用途：页面备份用于工作流数据迁移，具体是否包含视频以界面说明为准；完整快照覆盖全部数据库和上传文件，包括账号认证数据，应按敏感内部资料管理。

为取得完整一致的素材快照，先暂停上传与修改，最好停止应用。直接部署示例：

```sh
# 先停止应用进程，保留 .data
python3 scripts/backup.py backup .data /safe/backup/frameflow-2026-10-15.tgz
# 恢复只允许写到不存在的新目录，避免覆盖现有工作。
python3 scripts/backup.py restore /safe/backup/frameflow-2026-10-15.tgz /safe/restore/frameflow-data
# 以原服务用户设置目录权限，将 VIDEOQA_DATA 指向恢复目录，再启动。
```

Docker 部署可以在停写后用 Compose 一次性容器执行备份脚本：

```sh
# scripts/backup.py 使用读取的数据库备份 API，不直接拷贝 SQLite WAL 文件。
docker compose --env-file deploy/.env -f deploy/compose.yaml stop app
mkdir -p backups
# 临时维护容器以 root 读取数据卷，备份文件权限为 0600；不改变应用的非 root 运行配置。
docker compose --env-file deploy/.env -f deploy/compose.yaml run --rm --no-deps --user 0:0 --volume "$PWD/backups:/backup" app python3 scripts/backup.py backup /data /backup/frameflow-snapshot.tgz
# 再次启动应用与网关：
docker compose --env-file deploy/.env -f deploy/compose.yaml up -d
```

请制定定期备份、加密存储、保留周期和恢复演练。不要执行 `docker compose down -v`，这会删除持久化卷。恢复工具会清除已恢复的会话，成员必须重新登录。

## 账号密码恢复

忘记密码时，由持有服务器控制台权限的运维人员执行（交互式输入，不把密码放到命令或日志中）：

```sh
VIDEOQA_DATA=/absolute/path/to/private-data python3 manage.py reset-password admin@company.com
# Docker 部署：
docker compose --env-file deploy/.env -f deploy/compose.yaml exec app python3 manage.py reset-password admin@company.com
```

该操作只重置指定已有账号的密码并使其原有会话失效，不创建新管理员，不启用已停用账号。操作会记录审计事件。

## 离线版

双击 `offline/帧序-离线视频评测.html`，推荐最新 Chrome 或 Edge。视频与评测数据保存在当前浏览器的 IndexedDB 中。离线身份用于区分本机评测人，不是账号认证；分享 HTML 不会分享数据。清理浏览器存储、使用隐私模式、修改文件位置或切换浏览器可能使原数据不可用。应按离线界面提示导出完整备份并验证恢复。

离线版没有联网资源依赖；可在网络断开后导入本机视频和完成评测。需要真正多人协作时使用在线版。

## 验证与维护

```sh
python3 -m unittest tests_backend tests_snapshot tests_manage qa_extra -v
node --check public/app.js
node --check offline_adapter.js
python3 build_offline.py
```

浏览器验收脚本需要 Node.js、Playwright 和 Chrome/Chromium，详见 `验收报告.md`。`tests/fixtures/test-pattern.mp4` 是本项目生成的 3 秒测试图案与正弦音，用于可复验的上传和播放检查，不是真实业务素材。自动化测试在独立临时数据库中执行，不改动实际工作数据。具体通过数量与限制见报告；有限的测试不能证明所有浏览器、所有输入或未来部署都无缺陷。

上线前由公司确认管理员持有人、域名 TLS、访问范围、素材授权与数据保留规则，完成自身安全与运维验收。项目提供应用级邀请、权限、会话、CSRF 防护和操作记录；不包含公司 SSO、第三方渗透认证、抗 DDoS 设施、跨组织隔离或法律合规认证。
