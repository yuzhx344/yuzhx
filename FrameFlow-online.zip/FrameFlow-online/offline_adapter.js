/* FrameFlow offline adapter. No network, authentication service, or external dependency. */
(() => {
  'use strict';
  const DB_NAME = 'FrameFlow-Offline-v2';
  const MAX_VIDEO_BYTES = 250 * 1024 * 1024;
  const MAX_SINGLE_VIDEO_BYTES = 200 * 1024 * 1024;
  const MAX_METADATA_BYTES = 32 * 1024 * 1024;
  const MAX_BACKUP_BYTES = 400 * 1024 * 1024;
  const statuses = ['待评测','评测中','待复核','已通过','已退回'];
  const verdicts = ['通过','需复核','退回'];
  const scenes = ['mountain','city','forest','coast','portrait','desert'];
  const blobURLs = new Map();
  const stagedVideos = new Map();
  let memoryIdentity = null;
  const clone = x => structuredClone(x);
  const now = () => new Date().toISOString();
  const uuid = () => globalThis.crypto?.randomUUID?.() || `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const fail = message => { throw new Error(message); };
  const isObject = x => !!x && typeof x === 'object' && !Array.isArray(x);
  const positiveID = x => Number.isSafeInteger(x) && x > 0;
  const identity = () => { try { return Number(sessionStorage.getItem('frameflow-offline-identity')) || memoryIdentity; } catch { return memoryIdentity; } };
  const setIdentity = id => { memoryIdentity = id || null; try { id ? sessionStorage.setItem('frameflow-offline-identity', String(id)) : sessionStorage.removeItem('frameflow-offline-identity'); } catch {} };
  const text = (value, label, maximum, required = false) => {
    if (value == null) value = '';
    if (typeof value !== 'string' || value.length > maximum || /\u0000/.test(value)) fail(`${label}格式无效或超过 ${maximum} 字符`);
    value = value.trim();
    if (required && !value) fail(`请填写${label}`);
    return value;
  };
  function arrayText(value, label, maximum = 20, chars = 80) {
    if (value == null) return [];
    if (!Array.isArray(value) || value.length > maximum) fail(`${label}数量无效`);
    return [...new Set(value.map(x => text(x, label, chars, true)))];
  }
  function initialWorkspace() {
    const samples = [
      ['山海之间 · 自然风光精选','material','自然风光','00:32','mountain'],
      ['城市脉搏 · 雨夜霓虹','material','城市建筑','00:24','city'],
      ['森林晨光 · 生态纪实','material','自然风光','00:18','forest'],
      ['海岸线 · 航拍素材','material','自然风光','00:46','coast'],
      ['光影人像 · 午后时刻','material','人物生活','00:15','portrait'],
      ['沙漠行者 · 旅行记录','material','旅行人文','00:28','desert'],
      ['海边奔跑的金毛犬','aigc','文生视频','00:08','coast'],
      ['未来城市 · 悬浮列车','aigc','文生视频','00:12','city'],
      ['微风中的森林小屋','aigc','图生视频','00:06','forest'],
      ['雪山日出 · 延时镜头','aigc','图生视频','00:10','mountain']
    ];
    const stamp = now();
    return {schema:2,workspace_id:'offline-'+uuid(),revision:1,users:[],reviews:[],media:{},audit:[],tasks:samples.map((s,i)=>({id:i+1,title:s[0],kind:s[1],category:s[2],duration:s[3],scene:s[4],status:'待评测',is_demo:1,url:'',created_by:null,created_at:stamp,updated_at:stamp,description:'内置流程示例，不包含真实视频，请导入本地视频后开展正式评测。',prompt:'',model:'',version:'',source:'内置示例',assignee:null,tags:[],priority:'中',due_date:''}))};
  }
  const ready = new Promise((resolve,reject) => {
    if (!globalThis.indexedDB) return reject(new Error('此浏览器不支持 IndexedDB，无法可靠保存离线视频。请使用 Chrome 或 Edge 普通窗口打开。'));
    let request;
    try { request = indexedDB.open(DB_NAME, 1); } catch { return reject(new Error('浏览器阻止了离线存储，请使用 Chrome / Edge 普通窗口，并允许本地网页保存数据。')); }
    request.onupgradeneeded = () => {
      const db = request.result;
      db.createObjectStore('meta');
      db.createObjectStore('videos');
      request.transaction.objectStore('meta').put(initialWorkspace(), 'workspace');
    };
    request.onerror = () => reject(new Error('无法打开本地数据库。请退出隐私模式，检查浏览器存储权限及磁盘空间。'));
    request.onblocked = () => reject(new Error('离线数据库被旧窗口占用。请关闭其他帧序离线页面后重新打开。'));
    request.onsuccess = () => {
      request.result.onversionchange = () => request.result.close();
      resolve(request.result);
    };
  });
  // Attach immediately so a disabled IndexedDB never produces an unhandled rejection.
  ready.catch(()=>{});
  function storageError(error) {
    if (error?.name === 'QuotaExceededError') return new Error('本地存储空间不足，操作未保存。请先导出完整备份，再释放磁盘空间。');
    return error instanceof Error ? error : new Error('本地数据库操作失败，原有数据未被替换。');
  }
  async function transaction(mode, action, includeVideos = true) {
    const db = await ready;
    return new Promise((resolve,reject)=>{
      let result, failure;
      const tx = db.transaction(includeVideos ? ['meta','videos'] : ['meta'], mode);
      const meta = tx.objectStore('meta');
      const videos = includeVideos ? tx.objectStore('videos') : null;
      const read = meta.get('workspace');
      read.onsuccess = () => {
        try {
          const ws = read.result;
          if (!ws || ws.schema !== 2) fail('本地数据格式不受支持，请保留文件并联系管理员。');
          result = action(ws, videos, meta, tx);
          if (mode === 'readwrite') { ws.revision++; if(new Blob([JSON.stringify(ws)]).size>MAX_METADATA_BYTES)fail('工作空间任务与评测元数据已超过 32 MiB，本次操作未保存。请先导出完整备份后精简任务，或使用在线版。');meta.put(ws, 'workspace'); }
        } catch(error) { failure=error; tx.abort(); }
      };
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(storageError(failure || tx.error));
      tx.onerror = () => {};
    });
  }
  function currentUser(ws) {
    const user = ws.users.find(u => u.id === identity() && u.active !== 0);
    if (!user) fail('请先选择或创建本机评测身份。离线身份不提供密码认证。');
    return user;
  }
  function admin(ws) { const user=currentUser(ws); if(user.role!=='admin') fail('此操作需切换到本机管理员身份。离线角色用于流程演示，不构成安全权限。'); return user; }
  function log(ws,actor,action,details) {
    ws.audit.push({id:uuid(),actor_id:actor?.id||null,actor_name:actor?.name||'本机用户',user_id:actor?.id||null,name:actor?.name||'本机用户',action,target:details,detail:JSON.stringify({message:details}),details,created_at:now()});
    if(ws.audit.length>1000) ws.audit.splice(0,ws.audit.length-1000);
  }
  function taskInput(data, ws, previous) {
    if(!isObject(data)) fail('任务数据格式错误');
    const merged = {...previous,...data};
    if(!['material','aigc'].includes(merged.kind)) fail('请选择有效的评测类型');
    const url=text(merged.url,'本地视频引用',2000);
    const storedURL = url.startsWith('blob:') ? [...blobURLs].find(([,value])=>value.url===url)?.[0] : url;
    if(storedURL && (!/^local:[a-zA-Z0-9-]+$/.test(storedURL)||!ws.media[storedURL])) fail('视频未保存在本机，请重新选择并上传本地 MP4 / WebM 视频。');
    if(!storedURL && !previous?.is_demo) fail('请选择并上传本地视频');
    const duration=text(merged.duration||'00:00','视频时长',12,true);
    if(!/^\d{2,4}:[0-5]\d$/.test(duration)) fail('视频时长请使用 分钟:秒 格式，例如 00:15');
    const assignee = merged.assignee == null || merged.assignee === '' ? null : Number(merged.assignee);
    if(assignee!==null && !ws.users.some(u=>u.id===assignee&&u.active!==0)) fail('指定评测员不存在或已停用');
    const due_date=text(merged.due_date,'截止日期',10);
    if(due_date && (!/^\d{4}-\d{2}-\d{2}$/.test(due_date)||new Date(due_date+'T00:00:00Z').toISOString().slice(0,10)!==due_date)) fail('截止日期无效');
    const priority=merged.priority||'中'; if(!['低','中','高'].includes(priority)) fail('优先级无效');
    return {title:text(merged.title,'任务名称',150,true),kind:merged.kind,category:text(merged.category||'待分类','内容分类',40,true),duration,url:storedURL||'',scene:scenes.includes(merged.scene)?merged.scene:'mountain',is_demo:storedURL?0:1,description:text(merged.description,'任务说明',5000),prompt:text(merged.prompt,'生成提示词',5000),model:text(merged.model,'生成模型',100),version:text(merged.version,'模型版本',100),source:text(merged.source,'素材来源',300),assignee,tags:arrayText(merged.tags,'标签'),priority,due_date};
  }
  function reviewInput(data,ws) {
    if(!isObject(data) || !positiveID(data.task_id)) fail('评测任务编号无效');
    const task=ws.tasks.find(t=>t.id===data.task_id); if(!task) fail('任务不存在，可能已被删除');
    if(task.resolution_verdict && !data._restoring) fail('此任务已有管理员裁定，不能继续修改独立评分。');
    if(task.is_demo || !task.url || !ws.media[task.url]) fail('示例任务不能提交正式评分，请先导入本地视频');
    if(!Array.isArray(data.scores)||data.scores.length!==5||data.scores.some(x=>!Number.isInteger(x)||x<1||x>5)) fail('五项质量评分必须为 1 到 5 的整数');
    if(!verdicts.includes(data.verdict)) fail('质量结论无效');
    const note=text(data.note,'问题描述',3000);
    if(data.verdict!=='通过' && !note) fail('退回或需复核时，请填写问题描述和发生位置');
    const timecodes = data.timecodes == null ? [] : data.timecodes;
    if(!Array.isArray(timecodes)||timecodes.length>100) fail('问题时间点格式无效');
    return {task_id:task.id,scores:JSON.stringify(data.scores),verdict:data.verdict,note,issues:arrayText(data.issues,'问题标签',30,80),timecodes:timecodes.map(tc=>{
      if(typeof tc==='string') return text(tc,'问题时间点',200,true);
      if(!isObject(tc)) fail('问题时间点格式无效');
      // Structured time annotations from supported clients remain simple JSON.
      const out={};for(const key of ['start','end','time','label','note']) if(tc[key]!=null){if(typeof tc[key]==='number'){if(!Number.isFinite(tc[key])||tc[key]<0||tc[key]>86400)fail('问题时间超出范围');out[key]=tc[key];}else out[key]=text(tc[key],'问题时间点',500);}
      if(!Object.keys(out).length)fail('问题时间点为空');return out;
    })};
  }
  function persistStagedVideo(data,ws,videos) {
    const key=data?.url;
    if(!key||ws.media[key])return;
    const draft=stagedVideos.get(key);if(!draft)return;
    const total=Object.values(ws.media).reduce((sum,item)=>sum+item.size,0);
    if(total+draft.size>MAX_VIDEO_BYTES)fail('本地视频总量超过 250 MiB，任务未保存');
    const {blob,...metadata}=draft;ws.media[key]=metadata;videos.put(draft,key);
  }
  function statusFor(reviews) {
    if(!reviews.length)return '待评测';
    const votes=reviews.map(r=>r.verdict);
    return votes.includes('需复核')||new Set(votes).size>1?'待复核':votes.length<2?'评测中':votes[0]==='通过'?'已通过':'已退回';
  }
  function revokeMissing(media) {
    for(const [key,item] of blobURLs) if(!media[key] || media[key].checksum_id!==item.checksum_id){URL.revokeObjectURL(item.url);blobURLs.delete(key);}
  }
  async function readState() {
    const db=await ready;
    const snapshot = await new Promise((resolve,reject)=>{
      const tx=db.transaction(['meta','videos'],'readonly');
      let ws,records=[];
      const a=tx.objectStore('meta').get('workspace');a.onsuccess=()=>ws=a.result;
      const b=tx.objectStore('videos').getAll();b.onsuccess=()=>records=b.result;
      tx.oncomplete=()=>resolve({ws,records});tx.onabort=()=>reject(storageError(tx.error));tx.onerror=()=>{};
    });
    const {ws,records}=snapshot;revokeMissing(ws.media);
    const files=new Map(records.map(x=>[x.id,x]));
    const tasks=ws.tasks.map(t=>{
      let url='';const key=t.url;
      if(key && files.has(key)){
        if(!blobURLs.has(key))blobURLs.set(key,{url:URL.createObjectURL(files.get(key).blob),checksum_id:ws.media[key]?.checksum_id});
        url=blobURLs.get(key).url;
      }
      return {...t,storage_url:key,url,media_missing:!!key&&!url,media_name:ws.media[key]?.name||'',media_size:ws.media[key]?.size||0};
    });
    const user=ws.users.find(u=>u.id===identity()&&u.active!==0)||null;
    return {tasks,reviews:ws.reviews,users:ws.users,user,bootstrap:ws.users.length===0,csrf:'offline',offline:true,workspace_id:ws.workspace_id,revision:ws.revision,config:{offline:true,registration_open:true,max_upload_bytes:MAX_SINGLE_VIDEO_BYTES},storage:{videos:Object.keys(ws.media).length,bytes:Object.values(ws.media).reduce((n,v)=>n+v.size,0),limit:MAX_VIDEO_BYTES}};
  }
  async function upload(file) {
    if(!(file instanceof Blob)||file.size===0)fail('请选择非空的视频文件');
    if(file.size>MAX_SINGLE_VIDEO_BYTES)fail('单个视频不能超过 200 MiB，请压缩或裁剪后重试');
    const header=new Uint8Array(await file.slice(0,16).arrayBuffer());
    const ascii=(start,len)=>String.fromCharCode(...header.slice(start,start+len));
    const atom=ascii(4,4),mov=['moov','mdat','wide'].includes(atom)&&(/\.mov$/i.test(file.name||'')||file.type==='video/quicktime');
    const mp4=atom==='ftyp',webm=header[0]===0x1a&&header[1]===0x45&&header[2]===0xdf&&header[3]===0xa3,ogg=ascii(0,4)==='OggS';
    if(!mp4&&!webm&&!ogg&&!mov)fail('文件内容不是支持的视频格式。请选择 MP4、WebM、MOV 或 Ogg 视频。');
    const mime=mov||(mp4&&(/\.mov$/i.test(file.name||'')||file.type==='video/quicktime'))?'video/quicktime':mp4?'video/mp4':webm?'video/webm':'video/ogg';
    const id='local:'+uuid(), name=text(file.name||'video.mp4','视频文件名',250,true),checksum_id=uuid();
    await transaction('readonly',ws=>{
      currentUser(ws);
      const total=Object.values(ws.media).reduce((sum,item)=>sum+item.size,0);
      if(total+file.size>MAX_VIDEO_BYTES)fail('当前工作空间视频总量上限为 250 MiB。请先导出完整备份，再删除不再需要的任务及视频。');
    },false);
    // The selected file remains a draft until task creation commits it atomically.
    // Choosing another file replaces the previous draft; cancel/reload leaves no orphan media.
    stagedVideos.clear();
    stagedVideos.set(id,{id,name,mime,size:file.size,checksum_id,created_at:now(),blob:file.slice(0,file.size,mime)});
    return {url:id,name,size:file.size,mime};
  }
  async function digest(bytes) {
    if(!globalThis.crypto?.subtle)fail('浏览器不支持视频备份完整性校验，请使用最新版 Chrome 或 Edge');
    return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  }
  async function exportBackup() {
    const db=await ready;
    const snapshot=await new Promise((resolve,reject)=>{
      const tx=db.transaction(['meta','videos'],'readonly');let ws,records;
      const a=tx.objectStore('meta').get('workspace');a.onsuccess=()=>ws=a.result;
      const b=tx.objectStore('videos').getAll();b.onsuccess=()=>records=b.result;
      tx.oncomplete=()=>{try{admin(ws);resolve({ws,records});}catch(e){reject(e);}};
      tx.onabort=()=>reject(storageError(tx.error));tx.onerror=()=>{};
    });
    const {ws,records}=snapshot;
    if(records.reduce((n,r)=>n+r.size,0)>MAX_VIDEO_BYTES)fail('视频超过 250 MiB，无法安全生成完整备份');
    const videos=[];
    for(const record of records){
      const bytes=new Uint8Array(await record.blob.arrayBuffer());
      let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
      videos.push({id:record.id,name:record.name,mime:record.mime,size:record.size,sha256:await digest(bytes),data:btoa(binary)});
    }
    return {format:'frameflow-offline-backup',version:2,workspace_id:ws.workspace_id,exported_at:now(),media_included:true,users:ws.users.map(u=>({...u})),tasks:ws.tasks.map(t=>({...t})),reviews:clone(ws.reviews),audit:clone(ws.audit),videos};
  }
  function dateText(value,label){const v=text(value,label,50,true);if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(v)||!Number.isFinite(Date.parse(v)))fail(`${label}必须为有效 ISO UTC 时间`);const canonical=new Date(v).toISOString();if(canonical.slice(0,10)!==v.slice(0,10))fail(`${label}日期无效`);return canonical;}
  async function validateBackup(input) {
    if(!isObject(input)||input.format!=='frameflow-offline-backup'||input.version!==2||input.media_included!==true)fail('请选择由此离线版导出的 v2 完整备份。在线版仅数据备份不能直接导入离线视频。');
    if(!Array.isArray(input.users)||input.users.length>1000||!Array.isArray(input.tasks)||input.tasks.length>10000||!Array.isArray(input.reviews)||input.reviews.length>100000||!Array.isArray(input.videos)||input.videos.length>10000)fail('备份数据结构或记录数量无效');
    const ws={schema:2,workspace_id:text(input.workspace_id,'工作空间编号',100,true),revision:1,users:[],tasks:[],reviews:[],media:{},audit:[]};
    const unique=(items,label)=>{const seen=new Set();for(const item of items){if(!positiveID(item.id)||seen.has(item.id))fail(`${label}编号重复或无效`);seen.add(item.id);}};
    const emails=new Set();
    ws.users=input.users.map(u=>{
      if(!isObject(u))fail('身份记录格式错误');
      const email=text(u.email,'身份邮箱',254,true).toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||emails.has(email))fail('身份邮箱重复或无效');emails.add(email);
      if(!['admin','reviewer'].includes(u.role)||(u.active!==0&&u.active!==1&&u.active!==undefined))fail('身份角色或启用状态无效');
      return {id:u.id,name:text(u.name,'身份姓名',50,true),email,role:u.role,active:u.active===0?0:1,created_at:dateText(u.created_at||input.exported_at,'身份创建时间')};
    });unique(ws.users,'身份');
    if(ws.users.length&&!ws.users.some(u=>u.role==='admin'&&u.active!==0))fail('备份必须包含至少一位启用的本机管理员');
    const records=[];let bytesTotal=0;
    for(const video of input.videos){
      if(!isObject(video)||typeof video.id!=='string'||!/^local:[a-zA-Z0-9-]+$/.test(video.id)||ws.media[video.id]||!['video/mp4','video/webm','video/ogg','video/quicktime'].includes(video.mime)||!Number.isSafeInteger(video.size)||video.size<=0||video.size>MAX_SINGLE_VIDEO_BYTES)fail('备份视频记录无效');
      bytesTotal+=video.size;if(bytesTotal>MAX_VIDEO_BYTES)fail('备份视频超过 250 MiB，已取消恢复');
      if(typeof video.data!=='string'||video.data.length!==4*Math.ceil(video.size/3)||!/^[A-Za-z0-9+/]*={0,2}$/.test(video.data))fail('备份视频数据长度或编码无效');
      let binary;try{binary=atob(video.data);}catch{fail('备份视频 Base64 编码损坏');}if(binary.length!==video.size)fail('备份视频大小校验失败');
      const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
      if(typeof video.sha256!=='string'||!/^[0-9a-f]{64}$/.test(video.sha256)||await digest(bytes)!==video.sha256)fail('备份视频 SHA-256 完整性校验失败');
      const signature=String.fromCharCode(...bytes.subarray(4,8));
      if(video.mime==='video/quicktime'&&!['ftyp','moov','mdat','wide'].includes(signature)||video.mime==='video/mp4'&&signature!=='ftyp'||video.mime==='video/webm'&&!(bytes[0]===0x1a&&bytes[1]===0x45&&bytes[2]===0xdf&&bytes[3]===0xa3)||video.mime==='video/ogg'&&String.fromCharCode(...bytes.subarray(0,4))!=='OggS')fail('备份视频文件头校验失败');
      const record={id:video.id,name:text(video.name,'视频文件名',250,true),size:video.size,mime:video.mime,checksum_id:uuid(),created_at:now()};
      ws.media[video.id]=record;records.push({...record,blob:new Blob([bytes],{type:video.mime})});
    }
    ws.tasks=input.tasks.map(t=>{
      if(!isObject(t))fail('备份任务格式错误');
      const is_demo=t.is_demo===1||t.is_demo===true?1:0;
      const normalized=taskInput({...t,is_demo},ws,{is_demo});
      const created_by=t.created_by==null?null:Number(t.created_by);
      if(created_by!==null&&!ws.users.some(u=>u.id===created_by))fail('任务创建人不存在');
      if(!statuses.includes(t.status))fail('任务状态无效');
      let resolution={};if(t.resolution_verdict){if(!['通过','退回'].includes(t.resolution_verdict)||!ws.users.some(u=>u.id===t.resolution_by))fail('裁定结论或裁定人无效');resolution={resolution_verdict:t.resolution_verdict,resolution_by:t.resolution_by,resolution_at:dateText(t.resolution_at,'裁定时间'),resolution_note:text(t.resolution_note,'裁定说明',3000,true)};}
      return {...normalized,id:t.id,status:t.status,created_by,created_at:dateText(t.created_at,'任务创建时间'),updated_at:dateText(t.updated_at||t.created_at,'任务更新时间'),...resolution};
    });unique(ws.tasks,'任务');
    const reviewKeys=new Set();
    ws.reviews=input.reviews.map(r=>{
      if(!isObject(r))fail('备份评测格式错误');
      let scores;try{scores=typeof r.scores==='string'?JSON.parse(r.scores):r.scores;}catch{fail('评测分数格式错误');}
      const normalized=reviewInput({...r,scores,_restoring:true},ws);
      const user=ws.users.find(u=>u.id===r.user_id);if(!user)fail('评测记录的身份不存在');
      const key=`${r.task_id}:${r.user_id}`;if(reviewKeys.has(key))fail('同一身份对同一任务存在重复评分');reviewKeys.add(key);
      return {...normalized,id:r.id,user_id:user.id,name:user.name,created_at:dateText(r.created_at,'评测时间'),updated_at:dateText(r.updated_at||r.created_at,'评测更新时间')};
    });unique(ws.reviews,'评测');
    if(input.audit!==undefined&&(!Array.isArray(input.audit)||input.audit.length>1000))fail('审计记录格式无效');
    const auditIds=new Set();ws.audit=(input.audit||[]).map(a=>{
      if(!isObject(a))fail('审计记录格式无效');const id=text(a.id,'审计编号',100,true);if(auditIds.has(id))fail('审计编号重复');auditIds.add(id);
      const actor_id=a.actor_id??a.user_id??null;if(actor_id!==null&&!positiveID(actor_id))fail('审计操作人编号无效');
      const actor_name=text(a.actor_name||a.name||'本机用户','审计操作人',50,true);
      return {id,actor_id,actor_name,user_id:actor_id,name:actor_name,action:text(a.action,'审计操作',100,true),target:text(a.target,'审计对象',6000),detail:text(a.detail,'审计详情',10000),details:text(a.details,'审计说明',6000),created_at:dateText(a.created_at,'审计时间')};
    });
    // Recompute workflow state from actual independent reviews, never trust claimed completion.
    for(const task of ws.tasks){const reviews=ws.reviews.filter(r=>r.task_id===task.id);if(task.resolution_verdict&&reviews.length<2)fail('裁定任务必须保留至少两份独立评分');task.status=task.resolution_verdict?(task.resolution_verdict==='通过'?'已通过':'已退回'):statusFor(reviews);}
    return {ws,records};
  }
  async function restoreBackup(data) {
    if(!isObject(data)||data.mode!=='replace')fail('恢复模式无效，请选择完整替换');
    const restored=await validateBackup(data.backup);
    const actorID=identity();let actorEmail='';
    await transaction('readwrite',(ws,videos)=>{
      const actor=admin(ws);actorEmail=actor.email;
      const incoming=restored.ws;incoming.revision=ws.revision;
      log(incoming,actor,'restore',`完整恢复：${incoming.tasks.length} 个任务、${incoming.reviews.length} 份评分、${restored.records.length} 个视频`);
      for(const key of Object.keys(ws))delete ws[key];Object.assign(ws,incoming);
      videos.clear();for(const record of restored.records)videos.put(record,record.id);
    });
    if(!restored.ws.users.some(u=>u.id===actorID&&u.email===actorEmail&&u.active!==0))setIdentity(null);
    for(const item of blobURLs.values())URL.revokeObjectURL(item.url);blobURLs.clear();
    return {ok:true,restored:{tasks:restored.ws.tasks.length,reviews:restored.ws.reviews.length,videos:restored.records.length}};
  }
  async function api(path,data,method) {
    path=String(path||'').replace(/^\/?api\//,'').replace(/^\//,'');
    const verb=method||(data===undefined?'GET':'POST');
    if(path==='state'&&verb==='GET')return readState();
    if(path==='backup'&&verb==='GET')return exportBackup();
    if(path==='restore'&&verb==='POST')return restoreBackup(data);
    if(path==='audit'&&verb==='GET')return transaction('readonly',ws=>{admin(ws);return {events:clone(ws.audit).reverse(),audit:clone(ws.audit).reverse()};},false);
    if(path==='logout'){setIdentity(null);return {ok:true};}
    if(path==='login'){
      const user=await transaction('readonly',ws=>{
        const email=text(data?.email,'身份邮箱',254,true).toLowerCase();const u=ws.users.find(u=>u.email===email&&u.active!==0);if(!u)fail('未找到启用的本机身份，请先创建身份或使用已有身份邮箱');return u;
      },false);setIdentity(user.id);return {ok:true,user};
    }
    if(path==='register'){
      const user=await transaction('readwrite',ws=>{
        if(ws.users.length>=1000)fail('本机身份已达到 1000 个上限');
        const email=text(data?.email,'身份邮箱',254,true).toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail('请填写有效的身份邮箱');if(ws.users.some(u=>u.email===email))fail('本机已有此身份，请切换到该身份');
        const u={id:Math.max(0,...ws.users.map(u=>u.id))+1,name:text(data?.name,'身份姓名',50,true),email,role:ws.users.length?'reviewer':'admin',active:1,created_at:now()};ws.users.push(u);log(ws,u,'register','创建本机评测身份（无密码认证）');return u;
      });setIdentity(user.id);return {ok:true,user};
    }
    if(path==='invites')fail('离线版无需邀请码。请在本机创建评测身份；跨电脑协作请部署在线版。');
    return transaction('readwrite',(ws,videos)=>{
      const user=currentUser(ws);
      if(path==='tasks'&&verb==='POST'){
        if(ws.tasks.length>=10000)fail('当前工作空间最多保存 10000 个任务');
        persistStagedVideo(data,ws,videos);
        const values=taskInput(data,ws);const id=Math.max(0,...ws.tasks.map(t=>t.id))+1;
        ws.tasks.push({...values,id,status:'待评测',created_by:user.id,created_at:now(),updated_at:now()});log(ws,user,'task.create',values.title);return {ok:true,id};
      }
      const resolveRoute=/^tasks\/(\d+)\/resolve$/.exec(path);
      if(resolveRoute&&verb==='POST'){
        admin(ws);const task=ws.tasks.find(t=>t.id===Number(resolveRoute[1]));if(!task)fail('任务不存在');
        if(task.is_demo||!task.url)fail('示例任务不能正式裁定');
        if(!['通过','退回'].includes(data?.verdict))fail('裁定结论无效');
        if(ws.reviews.filter(r=>r.task_id===task.id).length<2)fail('至少需要两位成员独立评分后才可裁定');
        Object.assign(task,{resolution_by:user.id,resolution_at:now(),resolution_note:text(data.note,'裁定说明',3000,true),resolution_verdict:data.verdict,status:data.verdict==='通过'?'已通过':'已退回',updated_at:now()});
        log(ws,user,'task.resolve',task.title+' '+data.verdict);return {ok:true};
      }
      const taskRoute=/^tasks\/(\d+)$/.exec(path);
      if(taskRoute){
        const id=Number(taskRoute[1]),task=ws.tasks.find(t=>t.id===id);if(!task)fail('任务不存在');
        if(user.role!=='admin'&&task.created_by!==user.id)fail('仅本机管理员或任务创建者可修改任务');
        if(verb==='DELETE'){
          ws.tasks=ws.tasks.filter(t=>t.id!==id);ws.reviews=ws.reviews.filter(r=>r.task_id!==id);
          if(task.url&&!ws.tasks.some(t=>t.url===task.url)){delete ws.media[task.url];videos.delete(task.url);}
          log(ws,user,'task.delete',task.title);return {ok:true};
        }
        if(verb!=='POST')fail('任务操作方法无效');
        if(data?.expected_updated_at&&data.expected_updated_at!==task.updated_at)fail('此任务已被其他窗口更新，请刷新后重新编辑，避免覆盖最新内容');
        persistStagedVideo(data,ws,videos);
        const values=taskInput(data,ws,task),oldURL=task.url;
        if(oldURL!==values.url&&ws.reviews.some(r=>r.task_id===id))fail('已有评测记录的任务不能替换视频。请创建新任务，保留历史评测依据。');
        Object.assign(task,values,{updated_at:now()});
        if(oldURL&&oldURL!==values.url&&!ws.tasks.some(t=>t.url===oldURL)){delete ws.media[oldURL];videos.delete(oldURL);}
        log(ws,user,'task.update',task.title);return {ok:true,id};
      }
      if(path==='reviews'&&verb==='POST'){
        const values=reviewInput({...data,_restoring:false},ws);let review=ws.reviews.find(r=>r.task_id===values.task_id&&r.user_id===user.id);
        if(!review){review={id:Math.max(0,...ws.reviews.map(r=>r.id))+1,user_id:user.id,name:user.name,created_at:now()};ws.reviews.push(review);}
        Object.assign(review,values,{updated_at:now()});const task=ws.tasks.find(t=>t.id===values.task_id);task.status=statusFor(ws.reviews.filter(r=>r.task_id===task.id));task.updated_at=now();log(ws,user,'review.save',`VF-${task.id} ${values.verdict}`);return {ok:true,id:review.id};
      }
      if(path==='members'&&verb==='POST'){
        admin(ws);const member=ws.users.find(u=>u.id===Number(data?.user_id));if(!member)fail('本机身份不存在');
        const role=data.role||member.role,active=data.active==null?member.active:(data.active?1:0);if(!['admin','reviewer'].includes(role))fail('身份角色无效');
        if(member.role==='admin'&&member.active!==0&&(role!=='admin'||!active)&&!ws.users.some(u=>u.id!==member.id&&u.role==='admin'&&u.active!==0))fail('必须保留至少一位启用的本机管理员');
        member.role=role;member.active=active;log(ws,user,'member.update',member.name);return {ok:true};
      }
      fail('离线版不支持此操作：'+path);
    });
  }
  window.addEventListener('pagehide',event=>{if(event.persisted)return;stagedVideos.clear();for(const item of blobURLs.values())URL.revokeObjectURL(item.url);blobURLs.clear();});
  window.FRAMEFLOW_OFFLINE=true;
  window.FrameFlowAdapter=Object.freeze({offline:true,mode:'offline',api,upload,maxBackupBytes:MAX_BACKUP_BYTES,maxUploadBytes:MAX_SINGLE_VIDEO_BYTES});
})();
