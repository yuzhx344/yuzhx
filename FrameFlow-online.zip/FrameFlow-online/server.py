"""FrameFlow single-team server. Python 3.12+, standard library only."""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import mimetypes
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('VIDEOQA_DATA', str(ROOT / '.data')))
DB = DATA / 'videoqa.db'
MEDIA = DATA / 'media'
MAX_UPLOAD = 200 * 1024 * 1024
MAX_JSON = 20 * 1024 * 1024
STORAGE_LIMIT = int(os.environ.get('VIDEOQA_STORAGE_LIMIT_BYTES', str(10 * 1024 ** 3)))
UPLOAD_SLOTS = threading.BoundedSemaphore(4)
SESSION_SECONDS = 12 * 3600
SECURE_COOKIES = os.environ.get('SECURE_COOKIES', os.environ.get('VIDEOQA_SECURE_COOKIE', '0')) == '1'
PUBLIC_ORIGIN = os.environ.get('VIDEOQA_ORIGIN', '').rstrip('/')
TASK_STATUSES = {'待评测', '评测中', '待复核', '已通过', '已退回'}
VERDICTS = {'通过', '退回', '需复核'}
SCENES = {'mountain', 'city', 'forest', 'coast', 'portrait', 'desert'}


def now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def conn():
    c = sqlite3.connect(DB, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=15000')
    return c


def init():
    DATA.mkdir(parents=True, exist_ok=True, mode=0o700)
    MEDIA.mkdir(exist_ok=True, mode=0o700)
    if PUBLIC_ORIGIN:
        parsed = urlsplit(PUBLIC_ORIGIN)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.path or parsed.query or parsed.fragment or parsed.username:
            raise ValueError('VIDEOQA_ORIGIN must be an http(s) origin without path or credentials')
    with conn() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,password TEXT);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER,expires REAL);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,title TEXT,kind TEXT,category TEXT,duration TEXT,status TEXT DEFAULT '待评测',created_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,url TEXT DEFAULT '',scene TEXT DEFAULT 'mountain');
        CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,task_id INTEGER,user_id INTEGER,scores TEXT,note TEXT,verdict TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(task_id,user_id));
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS invites(code_hash TEXT PRIMARY KEY,role TEXT NOT NULL,created_by INTEGER,created_at TEXT,expires REAL NOT NULL,used_by INTEGER,used_at TEXT);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor_id INTEGER,action TEXT NOT NULL,target TEXT NOT NULL,detail TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS login_attempts(identity TEXT PRIMARY KEY,attempts INTEGER NOT NULL,first_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS uploads(id TEXT PRIMARY KEY,filename TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,sha256 TEXT NOT NULL,created_by INTEGER NOT NULL,created_at TEXT NOT NULL);
        ''')
        def add(table, name, declaration):
            cols = {r['name'] for r in c.execute(f'PRAGMA table_info({table})')}
            if name not in cols:
                c.execute(f'ALTER TABLE {table} ADD COLUMN {name} {declaration}')
                return True
            return False
        fresh_roles = add('users', 'role', "TEXT NOT NULL DEFAULT 'reviewer'")
        add('users', 'active', 'INTEGER NOT NULL DEFAULT 1')
        add('users', 'archived', 'INTEGER NOT NULL DEFAULT 0')
        if fresh_roles:
            c.execute("UPDATE users SET role='admin' WHERE id=(SELECT min(id) FROM users)")
        if add('sessions', 'csrf', "TEXT NOT NULL DEFAULT ''"):
            c.execute('DELETE FROM sessions')  # Legacy plaintext tokens are not retained.
        add('tasks', 'metadata', "TEXT NOT NULL DEFAULT '{}'")
        add('tasks', 'updated_at', "TEXT NOT NULL DEFAULT ''")
        add('tasks', 'resolution_by', 'INTEGER')
        add('tasks', 'resolution_at', "TEXT NOT NULL DEFAULT ''")
        add('tasks', 'resolution_note', "TEXT NOT NULL DEFAULT ''")
        add('tasks', 'resolution_verdict', "TEXT NOT NULL DEFAULT ''")
        add('reviews', 'issues', "TEXT NOT NULL DEFAULT '[]'")
        add('reviews', 'timecodes', "TEXT NOT NULL DEFAULT '[]'")
        c.execute("INSERT OR IGNORE INTO meta VALUES('workspace_id',?)", (str(uuid.uuid4()),))
        c.execute("INSERT OR IGNORE INTO meta VALUES('revision','0')")
        c.execute("INSERT OR REPLACE INTO meta VALUES('schema_version','2')")
        c.execute('CREATE INDEX IF NOT EXISTS sessions_expires ON sessions(expires)')
        c.execute('CREATE INDEX IF NOT EXISTS reviews_task ON reviews(task_id)')
        c.execute('CREATE INDEX IF NOT EXISTS audit_time ON audit(created_at)')
    try:
        DB.chmod(0o600)
    except OSError:
        pass


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 310000).hex()
    return f'pbkdf2_sha256$310000${salt}${digest}'


def password_ok(password, encoded):
    if not isinstance(encoded, str) or not encoded:
        return False
    try:
        if encoded.startswith('pbkdf2_sha256$'):
            _, iterations, salt, digest = encoded.split('$')
            count = int(iterations)
            if not 100000 <= count <= 1000000:
                return False
            expected = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), count).hex()
            return hmac.compare_digest(digest, expected)
        salt, digest = encoded.split(':')  # Upgrade old installations on login.
        return hmac.compare_digest(digest, hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 200000).hex())
    except (ValueError, TypeError):
        return False


def token_hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


def field(data, key, default='', maximum=3000, required=False):
    value = data.get(key, default)
    if not isinstance(value, str) or len(value) > maximum or '\x00' in value:
        raise APIError(400, f'{key} 必须为不超过 {maximum} 字符的文本')
    value = value.strip()
    if required and not value:
        raise APIError(400, f'请填写 {key}')
    return value


def ident(value, name='id'):
    if type(value) is not int or not 0 < value <= 9223372036854775807:
        raise APIError(400, f'{name} 必须为正整数')
    return value


def string_array(data, key, maximum=30, length=120):
    value = data.get(key, [])
    if not isinstance(value, list) or len(value) > maximum or any(not isinstance(x, str) or not x.strip() or len(x) > length or '\x00' in x for x in value):
        raise APIError(400, f'{key} 必须为文本数组，最多 {maximum} 项')
    return list(dict.fromkeys(x.strip() for x in value))


def timestamp_field(data, key, default='', required=False):
    value = field(data, key, default=default, maximum=50, required=required)
    if not value:
        return ''
    try:
        if 'T' not in value and ' ' not in value:
            raise ValueError()
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
    except ValueError:
        raise APIError(400, f'{key} 必须为有效 ISO 日期时间')


def task_out(row):
    result = dict(row)
    try:
        metadata = json.loads(result.pop('metadata', '{}'))
        if isinstance(metadata, dict):
            result.update({k: v for k, v in metadata.items() if k in {'description', 'prompt', 'model', 'version', 'source', 'assignee', 'tags', 'priority', 'due_date'}})
    except (ValueError, TypeError):
        pass
    result.setdefault('tags', [])
    result.setdefault('priority', '中')
    result.setdefault('assignee', None)
    result['demo'] = result.get('created_by') is None and not result.get('url')
    return result


def review_out(row):
    result = dict(row)
    for key in ('issues', 'timecodes'):
        try:
            result[key] = json.loads(result.get(key, '[]'))
        except (ValueError, TypeError):
            result[key] = []
    return result


def audit(c, actor, action, target='', detail=None):
    c.execute('INSERT INTO audit(actor_id,action,target,detail,created_at) VALUES(?,?,?,?,?)',
              (actor, action, str(target), json.dumps(detail or {}, ensure_ascii=False), now()))
    c.execute("UPDATE meta SET value=CAST(value AS INTEGER)+1 WHERE key='revision'")


def validate_url(c, url):
    if not url:
        return url
    if re.fullmatch(r'/media/[0-9a-f]{32}', url):
        if not c.execute('SELECT 1 FROM uploads WHERE id=?', (url.rsplit('/', 1)[1],)).fetchone():
            raise APIError(400, '本地视频文件不存在，请先重新上传视频')
        if not (MEDIA / url.rsplit('/', 1)[1]).is_file():
            raise APIError(400, '本地视频文件缺失，请恢复媒体备份或重新上传')
        return url
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or any(ord(x) < 33 for x in url):
            raise ValueError()
        _ = parsed.port
    except ValueError:
        raise APIError(400, '请使用有效 HTTP/HTTPS 视频地址或已上传的视频')
    return url


def validate_task(c, data, previous=None):
    if not isinstance(data, dict):
        raise APIError(400, '任务必须为对象')
    merged = dict(previous or {})
    merged.update(data)
    title = field(merged, 'title', maximum=150, required=True)
    kind = field(merged, 'kind', maximum=20)
    if kind not in ('material', 'aigc'):
        raise APIError(400, '任务类型必须为 material 或 aigc')
    url = validate_url(c, field(merged, 'url', maximum=3000))
    duration = field(merged, 'duration', default='00:00', maximum=12)
    if duration and not re.fullmatch(r'(?:\d{1,3}:)?\d{1,2}:[0-5]\d', duration):
        raise APIError(400, '时长请使用 mm:ss 或 hh:mm:ss 格式')
    scene = field(merged, 'scene', default='mountain', maximum=30)
    if scene not in SCENES:
        scene = 'mountain'
    metadata = {key: field(merged, key, maximum=10000 if key in ('description', 'prompt') else 200) for key in ('description', 'prompt', 'model', 'version', 'source')}
    metadata['tags'] = string_array(merged, 'tags')
    priority = field(merged, 'priority', default='中', maximum=10)
    if priority not in ('低', '中', '高'):
        raise APIError(400, '优先级必须为低、中或高')
    metadata['priority'] = priority
    assignee = merged.get('assignee')
    if assignee in ('', None):
        assignee = None
    else:
        ident(assignee, 'assignee')
        if not c.execute('SELECT 1 FROM users WHERE id=? AND active=1 AND archived=0', (assignee,)).fetchone():
            raise APIError(400, '指派成员不存在或已停用')
    metadata['assignee'] = assignee
    due = field(merged, 'due_date', maximum=10)
    if due:
        try:
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', due):
                raise ValueError()
            datetime.strptime(due, '%Y-%m-%d')
        except ValueError:
            raise APIError(400, '截止日期格式应为 YYYY-MM-DD')
    metadata['due_date'] = due
    return {'title': title, 'kind': kind, 'category': field(merged, 'category', default='待分类', maximum=60), 'duration': duration or '00:00', 'url': url, 'scene': scene, 'metadata': json.dumps(metadata, ensure_ascii=False)}


class Handler(BaseHTTPRequestHandler):
    server_version = 'FrameFlow'
    sys_version = ''
    protocol_version = 'HTTP/1.1'

    def setup(self):
        super().setup()
        self.connection.settimeout(45)

    def log_message(self, format, *args):
        # Do not log requests, credentials, invite codes, or uploaded filenames.
        return

    def common_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' blob: https: http:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")
        if SECURE_COOKIES:
            self.send_header('Strict-Transport-Security', 'max-age=31536000')

    def send(self, status, obj, headers=None):
        payload = json.dumps(obj, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()
        self.send_response(status)
        self.common_headers()
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(payload)

    def session(self, c):
        try:
            cookie = SimpleCookie(self.headers.get('Cookie', ''))
            raw = cookie.get('session')
            token = raw.value if raw else ''
        except CookieError:
            token = ''
        if not re.fullmatch(r'[0-9a-f]{64}', token):
            return None
        return c.execute('SELECT u.id,u.name,u.email,u.role,u.active,u.archived,s.csrf,s.token FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.active=1 AND u.archived=0', (token_hash(token), time.time())).fetchone()

    def auth(self, c, admin=False, csrf=False):
        user = self.session(c)
        if not user:
            raise APIError(401, '请先登录，再参与团队协作')
        if admin and user['role'] != 'admin':
            raise APIError(403, '此操作仅限管理员')
        if csrf and not hmac.compare_digest(self.headers.get('X-CSRF-Token', ''), user['csrf']):
            raise APIError(403, '安全校验失败，请刷新页面后重试')
        return user

    def origin_check(self):
        fetch_site = self.headers.get('Sec-Fetch-Site', '')
        if fetch_site == 'cross-site':
            raise APIError(403, '禁止跨站请求')
        origin = self.headers.get('Origin')
        if origin:
            target = PUBLIC_ORIGIN or ('https' if SECURE_COOKIES else 'http') + '://' + self.headers.get('Host', '')
            if origin != target:
                raise APIError(403, '请求来源与工作空间不一致')

    def body_length(self, maximum):
        if self.headers.get('Content-Encoding', 'identity').lower() != 'identity':
            self.close_connection = True
            raise APIError(415, '不支持压缩请求体')
        if self.headers.get('Transfer-Encoding'):
            self.close_connection = True
            raise APIError(400, '不支持分块请求，请提供 Content-Length')
        lengths = self.headers.get_all('Content-Length') or []
        if len(lengths) != 1 or not re.fullmatch(r'\d+', lengths[0]):
            self.close_connection = True
            raise APIError(400, '必须提供唯一且有效的 Content-Length')
        if len(lengths[0]) > 12:
            self.close_connection = True
            raise APIError(413, '请求超过大小限制')
        size = int(lengths[0])
        if size > maximum:
            self.close_connection = True
            raise APIError(413, '请求超过大小限制（视频 200 MB，JSON 20 MB）')
        return size

    def json_body(self):
        if self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower() != 'application/json':
            self.close_connection = True
            raise APIError(415, '请使用 application/json 请求')
        size = self.body_length(MAX_JSON)
        raw = self.rfile.read(size)
        if len(raw) != size:
            raise APIError(400, '请求数据不完整')
        try:
            data = json.loads(raw, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        except (ValueError, UnicodeError, RecursionError):
            raise APIError(400, 'JSON 请求格式错误')
        if not isinstance(data, dict):
            raise APIError(400, 'JSON 请求必须为对象')
        return data

    def cookie(self, token='', clear=False):
        return f'session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={0 if clear else SESSION_SECONDS}' + ('; Secure' if SECURE_COOKIES else '')

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            path = urlsplit(self.path).path
            if path == '/api/health':
                with conn() as c:
                    c.execute('SELECT 1 FROM meta LIMIT 1').fetchone()
                return self.send(200, {'ok': True, 'service': 'FrameFlow'})
            if path.startswith('/api/'):
                with conn() as c:
                    if path == '/api/state':
                        user = self.session(c)
                        bootstrap = not c.execute('SELECT 1 FROM users WHERE archived=0 LIMIT 1').fetchone()
                        base = {'user': None, 'tasks': [], 'reviews': [], 'users': [], 'csrf': None, 'bootstrap': bootstrap, 'revision': int(c.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0])}
                        if user:
                            base.update(user={k: user[k] for k in ('id', 'name', 'email', 'role')}, csrf=user['csrf'], tasks=[task_out(r) for r in c.execute('SELECT * FROM tasks ORDER BY id')], reviews=[review_out(r) for r in c.execute('SELECT r.*,u.name FROM reviews r JOIN users u ON u.id=r.user_id ORDER BY r.id')], users=[dict(r) for r in c.execute('SELECT id,name,role,active,archived FROM users ORDER BY id')])
                        return self.send(200, base)
                    user = self.auth(c, admin=True)
                    if path == '/api/audit':
                        events = [dict(r) for r in c.execute('SELECT a.*,u.name AS actor_name FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 500')]
                        return self.send(200, {'events': events})
                    if path == '/api/backup':
                        backup = {'format': 'frameflow-backup', 'version': 1, 'workspace_id': c.execute("SELECT value FROM meta WHERE key='workspace_id'").fetchone()[0], 'exported_at': now(), 'media_included': False, 'users': [dict(r) for r in c.execute('SELECT id,name,role FROM users ORDER BY id')], 'tasks': [task_out(r) for r in c.execute('SELECT * FROM tasks ORDER BY id')], 'reviews': [review_out(r) for r in c.execute('SELECT r.*,u.name FROM reviews r JOIN users u ON u.id=r.user_id ORDER BY r.id')]}
                        audit(c, user['id'], 'backup.export')
                        return self.send(200, backup, {'Content-Disposition': 'attachment; filename="frameflow-backup.json"'})
                raise APIError(404, '接口不存在')
            if path.startswith('/media/'):
                return self.serve_media(path)
            path = unquote(path)
            target = (ROOT / 'public' / ('index.html' if path == '/' else path.lstrip('/'))).resolve()
            if not target.is_relative_to((ROOT / 'public').resolve()) or not target.is_file() or target.name.startswith('.'):
                raise APIError(404, '页面不存在')
            content = target.read_bytes()
            self.send_response(200)
            self.common_headers()
            self.send_header('Content-Type', (mimetypes.guess_type(str(target))[0] or 'application/octet-stream') + ('; charset=utf-8' if target.suffix in ('.html', '.css', '.js', '.svg') else ''))
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(content)
        except APIError as error:
            self.send(error.status, {'error': error.message})
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except sqlite3.Error:
            self.send(503, {'error': '数据库暂时不可用，请稍后重试'})
        except (ValueError, TypeError, OverflowError, RecursionError):
            self.send(400, {'error': '请求格式或参数错误'})
        except OSError:
            self.send(503, {'error': '文件暂时不可用，请稍后重试'})

    def serve_media(self, path):
        if not re.fullmatch(r'/media/[0-9a-f]{32}', path):
            raise APIError(404, '视频不存在')
        key = path.rsplit('/', 1)[1]
        with conn() as c:
            self.auth(c)
            media = c.execute('SELECT * FROM uploads WHERE id=?', (key,)).fetchone()
        file = MEDIA / key
        if not media or not file.is_file():
            raise APIError(404, '视频文件不存在')
        size = file.stat().st_size
        start, end, status = 0, size - 1, 200
        requested = self.headers.get('Range')
        if requested:
            match = re.fullmatch(r'bytes=(\d{0,20})-(\d{0,20})', requested)
            if not match or not any(match.groups()):
                return self.send(416, {'error': '仅支持单段视频范围'}, {'Content-Range': f'bytes */{size}'})
            a, b = match.groups()
            if a:
                start = int(a)
                end = min(int(b), size - 1) if b else size - 1
            else:
                count = int(b)
                if count <= 0:
                    return self.send(416, {'error': '视频范围无效'}, {'Content-Range': f'bytes */{size}'})
                start = max(0, size - count)
            if start >= size or end < start:
                return self.send(416, {'error': '视频范围越界'}, {'Content-Range': f'bytes */{size}'})
            status = 206
        self.send_response(status)
        self.common_headers()
        self.send_header('Content-Type', media['mime'])
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Cache-Control', 'private, no-store')
        self.send_header('Content-Disposition', 'inline')
        if status == 206:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.end_headers()
        if self.command != 'HEAD':
            with file.open('rb') as source:
                source.seek(start)
                remaining = end - start + 1
                while remaining:
                    data = source.read(min(1024 * 1024, remaining))
                    if not data:
                        break
                    self.wfile.write(data)
                    remaining -= len(data)

    def do_DELETE(self):
        self.mutate(delete=True)

    def do_POST(self):
        self.mutate()

    def mutate(self, delete=False):
        try:
            # Error paths may reject before reading a body. Do not reuse that
            # connection, since unread bytes must never become another request.
            self.close_connection = True
            self.origin_check()
            path = urlsplit(self.path).path
            if path == '/api/upload' and not delete:
                if not UPLOAD_SLOTS.acquire(blocking=False):
                    raise APIError(429, '当前上传任务较多，请稍后重试')
                try:
                    return self.upload()
                finally:
                    UPLOAD_SLOTS.release()
            data = self.json_body()
            with conn() as c:
                c.execute('BEGIN IMMEDIATE')
                if path in ('/api/register', '/api/login') and not delete:
                    return self.login(c, path, data)
                user = self.auth(c, csrf=True)
                if path == '/api/logout' and not delete:
                    c.execute('DELETE FROM sessions WHERE token=?', (user['token'],))
                    audit(c, user['id'], 'auth.logout')
                    c.commit()
                    return self.send(200, {'ok': True}, {'Set-Cookie': self.cookie(clear=True)})
                if path == '/api/tasks' and not delete:
                    values = validate_task(c, data)
                    created = now()
                    cursor = c.execute('INSERT INTO tasks(title,kind,category,duration,created_by,url,scene,metadata,created_at,updated_at) VALUES(:title,:kind,:category,:duration,:created_by,:url,:scene,:metadata,:created_at,:updated_at)', {**values, 'created_by': user['id'], 'created_at': created, 'updated_at': created})
                    audit(c, user['id'], 'task.create', cursor.lastrowid)
                    result = {'ok': True, 'id': cursor.lastrowid}
                elif re.fullmatch(r'/api/tasks/\d+/resolve', path) and not delete:
                    if user['role'] != 'admin':
                        raise APIError(403, '此操作仅限管理员')
                    task_id = ident(int(path.split('/')[3]), 'task_id')
                    verdict = field(data, 'verdict', maximum=20)
                    note = field(data, 'note', maximum=6000, required=True)
                    if verdict not in ('通过', '退回'):
                        raise APIError(400, '仲裁结论必须为通过或退回')
                    task = c.execute('SELECT * FROM tasks WHERE id=?', (task_id,)).fetchone()
                    if not task:
                        raise APIError(404, '任务不存在')
                    if not task['url'] or c.execute('SELECT count(*) FROM reviews WHERE task_id=?', (task_id,)).fetchone()[0] < 2:
                        raise APIError(400, '任务需有视频和至少两位成员的独立评分才可仲裁')
                    status = '已通过' if verdict == '通过' else '已退回'
                    c.execute('UPDATE tasks SET status=?,resolution_by=?,resolution_at=?,resolution_note=?,resolution_verdict=?,updated_at=? WHERE id=?', (status, user['id'], now(), note, verdict, now(), task_id))
                    audit(c, user['id'], 'task.resolve', task_id, {'verdict': verdict, 'note': note})
                    result = {'ok': True, 'status': status}
                elif re.fullmatch(r'/api/tasks/\d+', path):
                    task_id = ident(int(path.rsplit('/', 1)[1]), 'task_id')
                    task = c.execute('SELECT * FROM tasks WHERE id=?', (task_id,)).fetchone()
                    if not task:
                        raise APIError(404, '任务不存在')
                    if user['role'] != 'admin' and task['created_by'] != user['id']:
                        raise APIError(403, '仅管理员或任务创建者可修改任务')
                    if delete:
                        c.execute('DELETE FROM reviews WHERE task_id=?', (task_id,))
                        c.execute('DELETE FROM tasks WHERE id=?', (task_id,))
                        audit(c, user['id'], 'task.delete', task_id, {'title': task['title']})
                    else:
                        if 'expected_updated_at' in data and data['expected_updated_at'] != task['updated_at']:
                            raise APIError(409, '任务已被其他成员修改，请刷新后重试')
                        values = validate_task(c, data, task_out(task))
                        if values['url'] != task['url'] and c.execute('SELECT 1 FROM reviews WHERE task_id=? LIMIT 1', (task_id,)).fetchone():
                            raise APIError(409, '已有评分的任务不可更换视频，请另建任务以保留评测记录')
                        c.execute('UPDATE tasks SET title=:title,kind=:kind,category=:category,duration=:duration,url=:url,scene=:scene,metadata=:metadata,updated_at=:updated_at WHERE id=:id', {**values, 'updated_at': now(), 'id': task_id})
                        audit(c, user['id'], 'task.update', task_id)
                    result = {'ok': True}
                elif path == '/api/reviews' and not delete:
                    result = self.review(c, user, data)
                elif path == '/api/invites' and not delete:
                    if user['role'] != 'admin':
                        raise APIError(403, '此操作仅限管理员')
                    role = field(data, 'role', default='reviewer', maximum=20)
                    if role not in ('admin', 'reviewer'):
                        raise APIError(400, '角色无效')
                    code = secrets.token_urlsafe(18)
                    expires = time.time() + 48 * 3600
                    c.execute('INSERT INTO invites(code_hash,role,created_by,created_at,expires) VALUES(?,?,?,?,?)', (token_hash(code), role, user['id'], now(), expires))
                    audit(c, user['id'], 'invite.create', detail={'role': role})
                    result = {'ok': True, 'code': code, 'expires_at': datetime.fromtimestamp(expires, timezone.utc).isoformat(), 'role': role}
                elif path == '/api/members' and not delete:
                    result = self.member(c, user, data)
                elif path == '/api/restore' and not delete:
                    if user['role'] != 'admin':
                        raise APIError(403, '此操作仅限管理员')
                    result = self.restore(c, user, data)
                else:
                    raise APIError(404, '接口不存在')
            return self.send(200, result)
        except APIError as error:
            return self.send(error.status, {'error': error.message})
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except sqlite3.IntegrityError:
            return self.send(409, {'error': '数据冲突，请刷新后重试'})
        except sqlite3.Error:
            return self.send(503, {'error': '数据库暂时不可用，请稍后重试'})
        except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
            return self.send(400, {'error': '请求格式或参数错误'})
        except OSError as error:
            if error.errno in (28, 122):
                return self.send(507, {'error': '服务器存储空间不足，请联系管理员'})
            return self.send(503, {'error': '文件存储暂时不可用，请稍后重试'})

    def login(self, c, path, data):
        email = field(data, 'email', maximum=254).lower()
        password = data.get('password', '')
        if not isinstance(password, str) or len(password) > 1024 or '\x00' in password:
            raise APIError(400, '密码格式无效或过长')
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            raise APIError(400, '请输入有效邮箱')
        identity = hashlib.sha256((self.client_address[0] + '|' + email).encode()).hexdigest()
        ip_identity = 'ip:' + hashlib.sha256(self.client_address[0].encode()).hexdigest()
        current = time.time()
        c.execute('DELETE FROM login_attempts WHERE first_at<?', (current - 900,))
        for key, limit in ((identity, 8), (ip_identity, 60)):
            attempt = c.execute('SELECT * FROM login_attempts WHERE identity=?', (key,)).fetchone()
            if attempt and attempt['attempts'] >= limit:
                c.commit()
                raise APIError(429, '登录尝试过多，请 15 分钟后重试')
        if path == '/api/register':
            name = field(data, 'name', maximum=50, required=True)
            if len(password) < 10:
                raise APIError(400, '密码至少 10 位，建议使用不同字符组合')
            exists = c.execute('SELECT 1 FROM users WHERE archived=0 LIMIT 1').fetchone()
            invitation = None
            if exists:
                code = field(data, 'invite_code', maximum=200, required=True)
                invitation = c.execute('SELECT * FROM invites WHERE code_hash=? AND used_by IS NULL AND expires>?', (token_hash(code), current)).fetchone()
                if not invitation:
                    raise APIError(403, '邀请码无效、已使用或已过期，请联系管理员')
            if c.execute('SELECT 1 FROM users WHERE email=?', (email,)).fetchone():
                raise APIError(409, '邮箱已注册，请直接登录')
            role = invitation['role'] if invitation else 'admin'
            cursor = c.execute('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)', (name, email, password_hash(password), role))
            uid = cursor.lastrowid
            if invitation:
                c.execute('UPDATE invites SET used_by=?,used_at=? WHERE code_hash=?', (uid, now(), invitation['code_hash']))
            audit(c, uid, 'auth.register', uid, {'role': role})
        user = c.execute('SELECT * FROM users WHERE email=? AND active=1 AND archived=0', (email,)).fetchone()
        if not user or not password_ok(password, user['password']):
            # Compute a real hash even for missing users to reduce account timing signals.
            if not user:
                password_hash(password)
            for key in (identity, ip_identity):
                c.execute('INSERT INTO login_attempts VALUES(?,1,?) ON CONFLICT(identity) DO UPDATE SET attempts=attempts+1', (key, current))
            c.commit()
            raise APIError(401, '邮箱或密码错误，或账号已停用')
        if not user['password'].startswith('pbkdf2_sha256$'):
            c.execute('UPDATE users SET password=? WHERE id=?', (password_hash(password), user['id']))
        c.execute('DELETE FROM login_attempts WHERE identity=?', (identity,))
        c.execute('DELETE FROM sessions WHERE expires<?', (current,))
        token, csrf = secrets.token_hex(32), secrets.token_hex(32)
        c.execute('INSERT INTO sessions(token,user_id,expires,csrf) VALUES(?,?,?,?)', (token_hash(token), user['id'], current + SESSION_SECONDS, csrf))
        # Cap active sessions per user; successful login rotates the supplied session.
        old = self.session(c)
        if old:
            c.execute('DELETE FROM sessions WHERE token=?', (old['token'],))
        c.execute('DELETE FROM sessions WHERE user_id=? AND token NOT IN (SELECT token FROM sessions WHERE user_id=? ORDER BY expires DESC LIMIT 10)', (user['id'], user['id']))
        audit(c, user['id'], 'auth.login')
        c.commit()
        return self.send(200, {'ok': True, 'csrf': csrf, 'user': {k: user[k] for k in ('id', 'name', 'email', 'role')}}, {'Set-Cookie': self.cookie(token)})

    def review(self, c, user, data):
        task_id = ident(data.get('task_id'), 'task_id')
        task = c.execute('SELECT * FROM tasks WHERE id=?', (task_id,)).fetchone()
        if not task:
            raise APIError(404, '任务不存在')
        if not task['url']:
            raise APIError(400, '请先为任务添加可播放视频，再进行正式评测')
        if task['resolution_verdict']:
            raise APIError(409, '此任务已由管理员仲裁，评测记录已锁定')
        scores = data.get('scores')
        if not isinstance(scores, list) or len(scores) != 5 or any(type(x) not in (int, float) or not math.isfinite(x) or not 1 <= x <= 5 for x in scores):
            raise APIError(400, '请为五个维度分别提供 1–5 分')
        verdict = field(data, 'verdict', maximum=20)
        if verdict not in VERDICTS:
            raise APIError(400, '评测结论无效')
        note = field(data, 'note', maximum=6000)
        if verdict != '通过' and not note:
            raise APIError(400, '退回或需复核时，请填写问题说明')
        issues = string_array(data, 'issues')
        timecodes = string_array(data, 'timecodes', maximum=50, length=80)
        c.execute('INSERT INTO reviews(task_id,user_id,scores,note,verdict,created_at,issues,timecodes) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(task_id,user_id) DO UPDATE SET scores=excluded.scores,note=excluded.note,verdict=excluded.verdict,created_at=excluded.created_at,issues=excluded.issues,timecodes=excluded.timecodes', (task_id, user['id'], json.dumps(scores), note, verdict, now(), json.dumps(issues, ensure_ascii=False), json.dumps(timecodes, ensure_ascii=False)))
        votes = [r[0] for r in c.execute('SELECT verdict FROM reviews WHERE task_id=?', (task_id,))]
        status = '待复核' if len(set(votes)) > 1 or '需复核' in votes else ('评测中' if len(votes) < 2 else ('已通过' if votes[0] == '通过' else '已退回'))
        c.execute('UPDATE tasks SET status=?,updated_at=? WHERE id=?', (status, now(), task_id))
        audit(c, user['id'], 'review.submit', task_id, {'verdict': verdict})
        return {'ok': True, 'status': status}

    def member(self, c, user, data):
        if user['role'] != 'admin':
            raise APIError(403, '此操作仅限管理员')
        uid = ident(data.get('user_id'), 'user_id')
        target = c.execute('SELECT * FROM users WHERE id=? AND archived=0', (uid,)).fetchone()
        if not target:
            raise APIError(404, '成员不存在')
        role = field(data, 'role', default=target['role'], maximum=20)
        if role not in ('admin', 'reviewer'):
            raise APIError(400, '角色无效')
        active = data.get('active', bool(target['active']))
        if type(active) is not bool:
            raise APIError(400, 'active 必须为布尔值')
        if target['role'] == 'admin' and target['active'] and (role != 'admin' or not active):
            if c.execute("SELECT count(*) FROM users WHERE role='admin' AND active=1 AND archived=0").fetchone()[0] <= 1:
                raise APIError(409, '工作空间必须至少保留一位启用的管理员')
        if uid == user['id'] and not active:
            raise APIError(409, '请由其他管理员停用当前账号')
        c.execute('UPDATE users SET role=?,active=? WHERE id=?', (role, int(active), uid))
        if not active or role != target['role']:
            c.execute('DELETE FROM sessions WHERE user_id=?', (uid,))
        audit(c, user['id'], 'member.update', uid, {'role': role, 'active': active})
        return {'ok': True}

    def upload(self):
        # Authenticate before reading an untrusted large body.
        self.close_connection = True
        with conn() as c:
            user = self.auth(c, csrf=True)
        size = self.body_length(MAX_UPLOAD)
        with conn() as c:
            used = c.execute('SELECT coalesce(sum(size),0) FROM uploads').fetchone()[0]
            if used + size > STORAGE_LIMIT:
                raise APIError(507, '工作空间媒体存储已达上限，请联系管理员归档或扩容')
        if size < 32:
            self.close_connection = True
            raise APIError(400, '视频为空或文件不完整')
        mime = self.headers.get('Content-Type', '').split(';', 1)[0].lower().strip()
        if mime not in ('video/mp4', 'video/webm', 'video/quicktime'):
            self.close_connection = True
            raise APIError(415, '仅支持 MP4、WebM 或 MOV 视频')
        name = unquote(self.headers.get('X-Filename', 'video'))
        name = re.sub(r'[\x00-\x1f\x7f/\\]', '_', name)[-180:] or 'video'
        key = secrets.token_hex(16)
        temp = MEDIA / ('.upload-' + key)
        target = MEDIA / key
        digest = hashlib.sha256()
        committed = False
        try:
            with temp.open('xb') as destination:
                remaining, prefix = size, b''
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise APIError(400, '视频上传中断，请重试')
                    if len(prefix) < 64:
                        prefix += chunk[:64 - len(prefix)]
                    destination.write(chunk)
                    digest.update(chunk)
                    remaining -= len(chunk)
                destination.flush()
                os.fsync(destination.fileno())
            valid = prefix.startswith(b'\x1aE\xdf\xa3') if mime == 'video/webm' else prefix[4:8] == b'ftyp'
            if not valid:
                raise APIError(415, '文件内容与视频格式不符，请选择真实 MP4、WebM 或 MOV 文件')
            temp.replace(target)
            target.chmod(0o600)
            with conn() as c:
                c.execute('BEGIN IMMEDIATE')
                # Role revocation during upload must still take effect.
                self.auth(c, csrf=True)
                used = c.execute('SELECT coalesce(sum(size),0) FROM uploads').fetchone()[0]
                if used + size > STORAGE_LIMIT:
                    raise APIError(507, '工作空间媒体存储已达上限，请联系管理员归档或扩容')
                c.execute('INSERT INTO uploads VALUES(?,?,?,?,?,?,?)', (key, name, mime, size, digest.hexdigest(), user['id'], now()))
                audit(c, user['id'], 'media.upload', key, {'bytes': size, 'mime': mime})
            committed = True
            return self.send(200, {'ok': True, 'id': key, 'url': '/media/' + key, 'name': name, 'size': size, 'mime': mime})
        except Exception:
            temp.unlink(missing_ok=True)
            if not committed:
                target.unlink(missing_ok=True)
            raise

    def restore(self, c, user, data):
        if data.get('mode') != 'replace':
            raise APIError(400, '请显式指定 mode=replace；还原将替换任务与评分')
        backup = data.get('backup')
        if not isinstance(backup, dict) or backup.get('format') != 'frameflow-backup' or type(backup.get('version')) is not int or backup.get('version') != 1:
            raise APIError(400, '备份格式或版本不受支持')
        tasks, reviews, users = backup.get('tasks'), backup.get('reviews'), backup.get('users')
        if not isinstance(tasks, list) or not isinstance(reviews, list) or not isinstance(users, list) or len(tasks) > 20000 or len(reviews) > 100000 or len(users) > 10000:
            raise APIError(400, '备份数据结构或数量不受支持')
        old_users = {}
        for row in users:
            if not isinstance(row, dict):
                raise APIError(400, '备份成员格式错误')
            uid = ident(row.get('id'), 'user.id')
            if uid in old_users:
                raise APIError(400, '备份成员 ID 重复')
            old_users[uid] = field(row, 'name', maximum=50, required=True)
        checked_tasks, task_ids, task_urls = [], set(), {}
        for row in tasks:
            if not isinstance(row, dict):
                raise APIError(400, '备份任务格式错误')
            tid = ident(row.get('id'), 'task.id')
            if tid in task_ids:
                raise APIError(400, '备份任务 ID 重复')
            task_ids.add(tid)
            # Validate all fields before altering any existing task.
            valid = validate_task(c, {**row, 'assignee': None})
            status = row.get('status', '待评测')
            if not isinstance(status, str) or status not in TASK_STATUSES:
                raise APIError(400, '备份任务状态错误')
            creator = row.get('created_by')
            if creator is not None:
                ident(creator, 'created_by')
                if creator not in old_users:
                    raise APIError(400, '备份任务引用了不存在的成员')
            assigned = row.get('assignee')
            if assigned is not None and (type(assigned) is not int or assigned not in old_users):
                raise APIError(400, '备份指派成员不存在')
            resolution = field(row, 'resolution_verdict', maximum=20)
            resolver = row.get('resolution_by')
            if resolution:
                if resolution not in ('通过', '退回'):
                    raise APIError(400, '备份仲裁结论无效')
                ident(resolver, 'resolution_by')
                if resolver not in old_users or not valid['url']:
                    raise APIError(400, '备份仲裁成员或视频缺失')
                field(row, 'resolution_note', maximum=6000, required=True)
                timestamp_field(row, 'resolution_at', required=True)
            elif resolver is not None:
                raise APIError(400, '备份仲裁字段不完整')
            timestamp_field(row, 'created_at', default=now())
            checked_tasks.append((row, valid))
            task_urls[tid] = valid['url']
        checked_reviews, keys = [], set()
        for row in reviews:
            if not isinstance(row, dict):
                raise APIError(400, '备份评测格式错误')
            tid, uid = ident(row.get('task_id'), 'review.task_id'), ident(row.get('user_id'), 'review.user_id')
            if tid not in task_ids or uid not in old_users or (tid, uid) in keys:
                raise APIError(400, '备份评测引用缺失或重复')
            if not task_urls.get(tid):
                raise APIError(400, '备份含无视频任务的评分，无法还原')
            keys.add((tid, uid))
            scores = row.get('scores')
            if isinstance(scores, str):
                try:
                    scores = json.loads(scores)
                except (ValueError, TypeError):
                    raise APIError(400, '备份评分格式错误')
            if not isinstance(scores, list) or len(scores) != 5 or any(type(x) not in (int, float) or not math.isfinite(x) or not 1 <= x <= 5 for x in scores):
                raise APIError(400, '备份评分必须为五个 1–5 分数值')
            verdict = field(row, 'verdict', maximum=20)
            if verdict not in VERDICTS:
                raise APIError(400, '备份评测结论错误')
            note = field(row, 'note', maximum=6000)
            issues = string_array(row, 'issues')
            timecodes = string_array(row, 'timecodes', maximum=50, length=80)
            timestamp_field(row, 'created_at', default=now())
            checked_reviews.append((row, scores, note, verdict, issues, timecodes))
        same = backup.get('workspace_id') == c.execute("SELECT value FROM meta WHERE key='workspace_id'").fetchone()[0]
        mapped = {}
        for uid, name in old_users.items():
            existing = c.execute('SELECT id,name FROM users WHERE id=?', (uid,)).fetchone() if same else None
            if existing and existing['name'] == name:
                mapped[uid] = uid
            else:
                mapped[uid] = c.execute("INSERT INTO users(name,email,password,role,active,archived) VALUES(?,NULL,'','reviewer',0,1)", (name,)).lastrowid
        c.execute('DELETE FROM reviews')
        c.execute('DELETE FROM tasks')
        for row, valid in checked_tasks:
            metadata = json.loads(valid['metadata'])
            assigned = mapped.get(row.get('assignee'))
            # Archived identities cannot receive new work.
            active_assignee = c.execute('SELECT 1 FROM users WHERE id=? AND active=1 AND archived=0', (assigned,)).fetchone() if assigned else None
            metadata['assignee'] = assigned if active_assignee else None
            valid['metadata'] = json.dumps(metadata, ensure_ascii=False)
            created = timestamp_field(row, 'created_at', default=now())
            c.execute('INSERT INTO tasks(id,title,kind,category,duration,status,created_by,created_at,url,scene,metadata,updated_at,resolution_by,resolution_at,resolution_note,resolution_verdict) VALUES(:id,:title,:kind,:category,:duration,:status,:created_by,:created_at,:url,:scene,:metadata,:updated_at,:resolution_by,:resolution_at,:resolution_note,:resolution_verdict)', {**valid, 'id': row['id'], 'status': '待评测', 'created_by': mapped.get(row.get('created_by')), 'created_at': created, 'updated_at': now(), 'resolution_by': mapped.get(row.get('resolution_by')), 'resolution_at': timestamp_field(row, 'resolution_at'), 'resolution_note': field(row, 'resolution_note', maximum=6000), 'resolution_verdict': field(row, 'resolution_verdict', maximum=20)})
        for row, scores, note, verdict, issues, timecodes in checked_reviews:
            c.execute('INSERT INTO reviews(task_id,user_id,scores,note,verdict,created_at,issues,timecodes) VALUES(?,?,?,?,?,?,?,?)', (row['task_id'], mapped[row['user_id']], json.dumps(scores), note, verdict, timestamp_field(row, 'created_at', default=now()), json.dumps(issues, ensure_ascii=False), json.dumps(timecodes, ensure_ascii=False)))
        for tid in task_ids:
            votes = [r[0] for r in c.execute('SELECT verdict FROM reviews WHERE task_id=?', (tid,))]
            resolution = c.execute('SELECT resolution_verdict FROM tasks WHERE id=?', (tid,)).fetchone()[0]
            if resolution and len(votes) < 2:
                raise APIError(400, '备份仲裁任务缺少两份独立评测记录')
            status = ('已通过' if resolution == '通过' else '已退回') if resolution else ('待评测' if not votes else ('待复核' if len(set(votes)) > 1 or '需复核' in votes else ('评测中' if len(votes) < 2 else ('已通过' if votes[0] == '通过' else '已退回'))))
            c.execute('UPDATE tasks SET status=? WHERE id=?', (status, tid))
        c.execute('DELETE FROM users WHERE archived=1 AND id NOT IN (SELECT user_id FROM reviews UNION SELECT created_by FROM tasks WHERE created_by IS NOT NULL UNION SELECT resolution_by FROM tasks WHERE resolution_by IS NOT NULL)')
        audit(c, user['id'], 'backup.restore', detail={'tasks': len(tasks), 'reviews': len(reviews), 'same_workspace': same})
        return {'ok': True, 'tasks': len(tasks), 'reviews': len(reviews), 'media_included': False}


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64


if __name__ == '__main__':
    init()
    host, port = os.environ.get('HOST', '127.0.0.1'), int(os.environ.get('PORT', '3000'))
    print(f'FrameFlow listening on {host}:{port}', flush=True)
    try:
        Server((host, port), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
