#!/usr/bin/env python3
"""Build the standalone offline HTML and a deterministic ZIP, without reading server data.

Run from any directory: python /path/to/FrameFlow/build_offline.py
No dependency installation or running server is needed.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'offline'
TITLE = '帧序-离线视频评测.html'


def inline_script(source: str) -> str:
    # Keep script-shaped text literals from closing the HTML raw-text element.
    return re.sub(r'</script', r'<\\/script', source, flags=re.I)


def build() -> None:
    inputs = {name: (ROOT / name).read_text(encoding='utf-8') for name in (
        'public/index.html', 'public/style.css', 'public/app.js', 'offline_adapter.js')}
    css = inputs['public/style.css']
    # Fonts must remain local in the offline deliverable. System CJK fonts are sufficient.
    css = re.sub(r'@import\s+(?:url\([^)]*\)|[\'"][^;]*[\'"])\s*;', '', css)
    if re.search(r'url\(\s*[\'"]?(?:https?:)?//', css, re.I):
        raise SystemExit('Offline build refused: stylesheet still contains an external asset.')
    app = inputs['public/app.js']
    if 'FrameFlowAdapter' not in app:
        raise SystemExit('Offline build refused: frontend adapter hook is missing.')
    html = inputs['public/index.html']
    css_tag = re.compile(r'<link\b(?=[^>]*\brel=[\'"]stylesheet[\'"])(?=[^>]*\bhref=[\'"]/style\.css[\'"])[^>]*>', re.I)
    html, styles = css_tag.subn(lambda _: '<style>' + css + '</style>', html)
    script_tag = re.compile(r'<script\b[^>]*\bsrc=[\'"]/app\.js[\'"][^>]*>\s*</script>', re.I)
    javascript = inline_script(inputs['offline_adapter.js']) + '\n' + inline_script(app)
    html, scripts = script_tag.subn(lambda _: '<script>' + javascript + '</script>', html)
    if styles != 1 or scripts != 1:
        raise SystemExit(f'Offline build refused: expected one CSS and one JS entry, got {styles}/{scripts}.')
    html = re.sub(r'<title>.*?</title>', '<title>帧序 FrameFlow · 离线视频评测</title>', html, count=1, flags=re.S)
    csp = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; media-src blob: data:; font-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"
    html = html.replace('<head>', '<head><meta http-equiv="Content-Security-Policy" content="' + csp + '">', 1)
    if re.search(r'<(?:script|link)\b[^>]*(?:src|href)=[\'"]/(?!/)', html, re.I):
        raise SystemExit('Offline build refused: a local server dependency remains.')
    notes = '''帧序 FrameFlow · 离线版 2.0

打开方式
1. 解压 ZIP，使用 Chrome 或 Edge 普通窗口打开“帧序-离线视频评测.html”。不需要安装或联网。
2. 在同一文件位置、同一浏览器配置中使用；不同浏览器或文件位置可能是独立存储空间。
3. 如公司浏览器禁止 file:// 本地网页，请联系 IT 使用允许本地网页的标准浏览器，或使用公司的在线部署版。不要绕过公司浏览器策略。

开始评测
1. 创建本机评测身份。第一位为本机管理员，后续身份为评测员。
2. 本机身份没有密码认证，角色仅用于离线评测流程；不要把它当作企业账号或权限边界。
3. 新建任务，导入本地 MP4 / WebM / MOV 视频。视频编码需要浏览器支持，H.264/AAC MP4 兼容性较好。
4. 先完整播放，再按五维标准评分，记录问题标签、时间点与结论。至少两位身份独立评测，一致完成；有分歧则进入复核。
5. 内置任务仅演示界面，没有视频，不计入正式质量结果，也不能提交正式评分。
6. 离线数据保存在当前浏览器 IndexedDB 中，任务、评分、身份及视频在同一数据库中保存。不支持跨电脑实时协作。

备份与恢复
1. 单个视频上限 200 MiB，工作空间视频总量上限 250 MiB，任务与评测元数据上限 32 MiB，避免完整备份时浏览器内存不足；大型数据集请使用在线版。
2. 在数据管理中导出“完整备份”，JSON 内包含身份、任务、评分、最近最多 1000 条离线审计以及全部已保存视频。视频使用 Base64，备份文件可能比视频大约 1/3。
3. CSV 评测报告用于表格分析，不包含视频，不能替代完整备份。
4. 恢复前请先导出现有完整备份。恢复为全量替换，覆盖当前离线工作空间的身份、任务、评分与视频；需明确确认。
5. 仅导入本离线版 v2 导出的完整 JSON 备份。在线版数据备份不含视频文件，格式不同，不能直接作为离线完整备份导入。
6. 恢复会先校验数据结构、编号、引用关系、评分、文件头、视频长度及 SHA-256 完整性，全部通过后以单事务替换。失败不会部分覆盖已有数据。
7. 旧版（v1）使用不同的浏览器存储，v2 不会覆盖或自动迁移旧数据。请保留旧版 HTML、原文件位置和浏览器，并先用旧版导出评测报告；正式评测建议在 v2 重新导入视频。
8. 清理浏览器数据、隐私窗口结束、系统空间不足都可能导致本地数据不可用。请及时下载完整备份到公司批准的存储位置。
9. 视频、问题说明及备份可能包含公司内容，应按公司数据管理要求保存；HTML 程序本身不包含你的工作空间数据。

与在线版的区别
在线版用于多人跨电脑共享任务、账号认证、角色管理与审计。离线版用于单机评测、离线展示、独立工作空间及完整备份迁移。本机身份切换不等于远程多人协作。

验收说明
本交付不依赖在线字体、图片、CDN 或网络 API，HTML 内的内容安全策略禁止联网。
开发环境对 file:// 受公司 Chromium URL 策略限制；已通过 localhost 加载同一单文件进行浏览器和断网检查。请在实际交付浏览器完成本地打开、导入视频、备份恢复的最终验收。

构建方式
在源码目录执行 python build_offline.py 即可重新生成。不需要连接数据库或运行服务器，也不会导出在线工作空间的账号、数据或视频。
'''
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT / TITLE).write_text(html, encoding='utf-8')
    (OUTPUT / '使用说明.txt').write_text(notes, encoding='utf-8')
    manifest = {
        'product': 'FrameFlow', 'edition': 'offline', 'version': '2.0',
        'entry': TITLE, 'external_dependencies': False,
        'source_sha256': {name: hashlib.sha256(value.encode()).hexdigest() for name,value in inputs.items()},
        'files_sha256': {TITLE: hashlib.sha256(html.encode()).hexdigest(), '使用说明.txt': hashlib.sha256(notes.encode()).hexdigest()},
    }
    (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(OUTPUT / 'FrameFlow-offline.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in (TITLE, '使用说明.txt', 'manifest.json'):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (OUTPUT / name).read_bytes())
    print(f'Built {OUTPUT / TITLE} ({len(html.encode()):,} bytes)')
    print(f'Built {OUTPUT / "FrameFlow-offline.zip"}')


if __name__ == '__main__':
    build()
