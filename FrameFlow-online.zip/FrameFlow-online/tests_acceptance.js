/* Run: node tests_acceptance.js. Requires playwright and a system Chromium. */
const {chromium}=require('playwright');
const {spawn}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),assert=require('assert');
(async()=>{
 const data=fs.mkdtempSync(path.join(os.tmpdir(),'frameflow-ui-'));
 const port=process.env.FF_TEST_PORT||'3456',base='http://127.0.0.1:'+port;
 const server=spawn('python3',['server.py'],{cwd:__dirname,env:{...process.env,VIDEOQA_DATA:data,HOST:'127.0.0.1',PORT:port},stdio:'ignore'});
 let browser;const passed=[],errors=[];const ok=(name,condition=true)=>{assert(condition,name);passed.push(name)};
 try{
  for(let i=0;i<50;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
  browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
  const ctx=await browser.newContext({viewport:{width:1440,height:1080},acceptDownloads:true}),p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));
  await p.goto(base);await p.waitForFunction(()=>document.querySelector('#profile')&&document.body.textContent.includes('创建'));
  await p.locator('#profile').click();await p.locator('#auth-form [name=name]').fill('验收管理员');await p.locator('#auth-form [name=email]').fill('accept-admin@example.com');await p.locator('#auth-form [name=password]').fill('accept-test-password-123');await p.locator('#auth-form button[type=submit]').click();await p.waitForFunction(()=>!document.querySelector('#auth-form'));ok('首次管理员注册与登录');
  await p.locator('#create').click();await p.locator('#create-form [name=title]').fill('验收视频 · 真实上传');await p.locator('#video-file').setInputFiles(process.env.FF_TEST_VIDEO||path.join(__dirname,'tests/fixtures/test-pattern.mp4'));await p.locator('#create-form [name=category]').fill('验收测试');await p.locator('#create-form button[type=submit]').click();await p.waitForFunction(()=>!document.querySelector('#create-form'));await p.waitForSelector('[data-task]');ok('真实MP4上传与任务创建');
  await p.locator('[data-task]').first().click();await p.waitForFunction(()=>{let v=document.querySelector('video');return v&&v.readyState>=2});ok('浏览器解码上传视频');await p.locator('video').evaluate(v=>{v.muted=true;return v.play()});await p.waitForFunction(()=>document.querySelector('video').currentTime>.2);await p.locator('video').evaluate(v=>v.pause());ok('实际视频播放');
  for(let i=0;i<5;i++)await p.locator(`[data-dim="${i}"] [data-score="4"]`).click();await p.locator('#review-form [name=verdict]').selectOption('通过');await p.locator('#review-form [name=note]').fill('真实视频完整播放，未见明显缺陷。');await p.locator('#review-form button[type=submit]').click();await p.waitForFunction(()=>!document.querySelector('#review-form'));ok('五维评分与结论提交');
  await p.locator('#search').fill('不存在的任务abcdef');await p.waitForFunction(()=>!document.querySelector('[data-task]'));ok('筛选空结果');await p.locator('#search').fill('');
  await p.locator('[data-page=team]').first().click();await p.locator('#invite').click();await p.locator('#invite-form button[type=submit]').click();await p.waitForSelector('.invite-code strong');const code=await p.locator('.invite-code strong').textContent();ok('管理员创建邀请');await p.keyboard.press('Escape');
  const second=await browser.newContext({viewport:{width:1440,height:1080}}),q=await second.newPage();q.on('pageerror',e=>errors.push(e.message));await q.goto(base);await q.waitForSelector('#profile');await q.locator('#profile').click();await q.locator('.switch-auth').click();await q.locator('#auth-form [name=name]').fill('验收评测员');await q.locator('#auth-form [name=email]').fill('accept-reviewer@example.com');await q.locator('#auth-form [name=password]').fill('accept-test-password-456');await q.locator('#auth-form [name=invite_code]').fill(code);await q.locator('#auth-form button[type=submit]').click();await q.waitForFunction(()=>!document.querySelector('#auth-form'));ok('第二浏览器接受邀请并加入同一空间');
  await q.locator('[data-task]').first().click();for(let i=0;i<5;i++)await q.locator(`[data-dim="${i}"] [data-score="2"]`).click();await q.locator('#review-form [name=verdict]').selectOption('退回');await q.locator('#review-form [name=note]').fill('00:01 主体存在测试图案，请进入复核。');await q.locator('#review-form button[type=submit]').click();await q.waitForFunction(()=>!document.querySelector('#review-form'));await q.waitForFunction(()=>document.querySelector('.badge.待复核'));ok('跨浏览器独立评分及分歧流转');
  await p.locator('#refresh').click();await p.locator('[data-page=material]').first().click();await p.waitForSelector('.badge.待复核');
  await p.locator('[data-task]').first().click();
  await p.locator('#resolve-task').click();
  const adminResolve=p.locator('#resolve-form');if(await adminResolve.count()){await adminResolve.locator('[name=verdict]').selectOption('通过');await adminResolve.locator('[name=note]').fill('核对任务说明后，确认测试图案属于预期画面。');await adminResolve.locator('button[type=submit]').click();await p.waitForFunction(()=>!document.querySelector('#resolve-form'));ok('管理员复核裁定')}
  if(await p.locator('.close').count())await p.locator('.close').click();
  fs.mkdirSync(path.join(__dirname,'artifacts'),{recursive:true});
  await p.waitForTimeout(400);await p.locator('#toast').evaluate(el=>{el.innerHTML='';el.className=''});await p.screenshot({path:path.join(__dirname,'artifacts','在线版-桌面.png'),fullPage:true});
  for(const name of ['overview','material','aigc','analytics','standards','cases','team','settings']){await p.locator(`[data-page=${name}]`).first().click();ok('页面可访问:'+name);if(name==='settings'){const download=p.waitForEvent('download');await p.locator('#backup').click();const d=await download;const file=path.join(data,'backup.json');await d.saveAs(file);const backup=JSON.parse(fs.readFileSync(file));ok('JSON备份无账号密码',!JSON.stringify(backup).includes('accept-test-password'));}}
  await p.locator('[data-page=material]').first().click();const csvPromise=p.waitForEvent('download');await p.locator('#export').click();const csv=await csvPromise;await csv.saveAs(path.join(data,'report.csv'));ok('CSV报告导出',fs.readFileSync(path.join(data,'report.csv'),'utf8').includes('验收视频'));
  await p.setViewportSize({width:390,height:844});await p.waitForTimeout(500);await p.locator('#toast').evaluate(el=>{el.innerHTML='';el.className=''});ok('手机侧栏默认收起',await p.locator('.sidebar').evaluate(el=>el.getBoundingClientRect().right<=1));await p.screenshot({path:path.join(__dirname,'artifacts','在线版-手机.png'),fullPage:true});ok('390px移动端无横向溢出',await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await p.locator('#mobile-menu').click();await p.locator('[data-page=standards]').first().click();ok('手机导航可用');
  ok('无JavaScript未捕获错误',errors.length===0);
  console.log(JSON.stringify({passed:passed.length,checks:passed,errors},null,2));fs.writeFileSync(path.join(__dirname,'artifacts','browser-results.json'),JSON.stringify({passed:passed.length,checks:passed,errors},null,2));
 }finally{if(browser)await browser.close();server.kill();fs.rmSync(data,{recursive:true,force:true})}
})().catch(e=>{console.error(e);process.exit(1)});
