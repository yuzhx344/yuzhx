"""Local-console administration. This script must be run by the service owner."""
import argparse
import getpass
from pathlib import Path
import os
import server

def reset_password(email,password):
    if not isinstance(password,str) or len(password)<10 or len(password)>1024:
        raise ValueError('新密码必须为 10–1024 个字符')
    if password != password.strip():raise ValueError('密码首尾不能包含空白字符')
    if not server.DB.is_file():raise ValueError('数据库不存在，请检查 VIDEOQA_DATA')
    with server.conn() as c:
        c.execute('BEGIN IMMEDIATE')
        u=c.execute('SELECT id,active,archived FROM users WHERE email=?',(email.strip().lower(),)).fetchone()
        if not u or u['archived']:raise ValueError('未找到此账号')
        c.execute('UPDATE users SET password=? WHERE id=?',(server.password_hash(password),u['id']))
        c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],))
        server.audit(c,u['id'],'auth.console_password_reset',u['id'],{'operator':'server-console'})
    return u['id']

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='FrameFlow 本机管理员恢复工具，不提供远程重置接口')
    parser.add_argument('command',choices=['reset-password']);parser.add_argument('email')
    args=parser.parse_args()
    if not server.DB.is_file():parser.exit(1,'数据库不存在，请检查 VIDEOQA_DATA\n')
    try:
        password=getpass.getpass('新密码（至少10位，不回显）：')
        if getpass.getpass('再次输入新密码：')!=password:raise ValueError('两次输入不一致')
        reset_password(args.email,password)
        print('密码已重置，该账号原有登录会话均已失效。')
    except (ValueError,EOFError,KeyboardInterrupt) as error:parser.exit(1,str(error)+'\n')
