"""Isolated API and migration regression suite; no live workspace data is used."""
import concurrent.futures
import copy
import hashlib
import http.client
import http.cookiejar
import importlib.util
import json
import os
import sqlite3
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

SPEC = importlib.util.spec_from_file_location('frameflow_test_server', Path(__file__).with_name('server.py'))
app = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(app)


class Client:
    def __init__(self, base):
        self.base, self.csrf = base, ''
        self.cookies = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookies))

    def call(self, path, data=None, method=None, headers=None, raw=None):
        sent = {'Content-Type': 'application/json'}
        if self.csrf:
            sent['X-CSRF-Token'] = self.csrf
        sent.update(headers or {})
        body = raw if raw is not None else (json.dumps(data, ensure_ascii=False).encode() if data is not None else None)
        req = urllib.request.Request(self.base + path, data=body, headers=sent, method=method)
        try:
            response = self.opener.open(req, timeout=10)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            payload = response.read()
            content_type = response.headers.get('Content-Type', '')
            parsed = json.loads(payload) if 'application/json' in content_type and payload else payload
            return response.status, parsed, response.headers

    def state(self):
        status, state, _ = self.call('/api/state')
        assert status == 200, state
        self.csrf = state.get('csrf') or ''
        return state


class BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.saved = app.DATA, app.DB, app.MEDIA
        app.DATA = Path(cls.temp.name)
        app.DB, app.MEDIA = app.DATA / 'videoqa.db', app.DATA / 'media'
        app.init()
        cls.server = app.Server(('127.0.0.1', 0), app.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        app.DATA, app.DB, app.MEDIA = cls.saved
        cls.temp.cleanup()

    def setUp(self):
        with app.conn() as c:
            for table in ('sessions', 'reviews', 'tasks', 'invites', 'audit', 'login_attempts', 'uploads', 'users'):
                c.execute(f'DELETE FROM {table}')
        for file in app.MEDIA.iterdir():
            file.unlink()
        self.guest = Client(self.base)
        self.admin = Client(self.base)
        self.register(self.admin, 'Admin', 'admin@example.com')

    def register(self, client, name, email, code=None):
        data = {'name': name, 'email': email, 'password': 'Strong-password-123'}
        if code:
            data['invite_code'] = code
        status, result, _ = client.call('/api/register', data)
        self.assertEqual(status, 200, result)
        client.state()
        return result

    def reviewer(self, name='Reviewer', email='reviewer@example.com'):
        status, invitation, _ = self.admin.call('/api/invites', {'role': 'reviewer'})
        self.assertEqual(status, 200, invitation)
        client = Client(self.base)
        self.register(client, name, email, invitation['code'])
        return client

    def task(self, client=None, **overrides):
        values = {'title': '真实视频任务', 'kind': 'aigc', 'category': '文生视频', 'duration': '00:08', 'url': 'https://example.com/video.mp4', 'tags': ['闪烁排查'], 'priority': '高'}
        values.update(overrides)
        status, result, _ = (client or self.admin).call('/api/tasks', values)
        self.assertEqual(status, 200, result)
        return result['id']

    def review(self, client, task_id, verdict='通过', **extra):
        return client.call('/api/reviews', {'task_id': task_id, 'scores': [4, 4.5, 3, 5, 4], 'verdict': verdict, 'note': '画面稳定，动态一致' if verdict == '通过' else '02 秒处闪烁，需要修复', 'issues': ['闪烁'] if verdict != '通过' else [], **extra})

    def test_bootstrap_auth_privacy_and_session_revocation(self):
        self.assertFalse(self.guest.state()['bootstrap'])
        self.task()
        self.assertEqual(self.guest.state()['tasks'], [])
        self.assertEqual(self.guest.state()['users'], [])
        self.assertEqual(self.admin.state()['user']['role'], 'admin')
        token = next(iter(self.admin.cookies)).value
        with app.conn() as c:
            stored = c.execute('SELECT token FROM sessions').fetchone()[0]
        self.assertNotEqual(token, stored)
        self.assertEqual(hashlib.sha256(token.encode()).hexdigest(), stored)
        self.assertEqual(self.admin.call('/api/logout', {})[0], 200)
        replay = Client(self.base)
        status, state, _ = replay.call('/api/state', headers={'Cookie': 'session=' + token})
        self.assertIsNone(state['user'])
        self.assertEqual(self.admin.call('/api/tasks', {'title': 'x', 'kind': 'material'})[0], 401)

    def test_invitation_required_single_use_and_roles(self):
        status, result, _ = self.guest.call('/api/register', {'name': 'No invite', 'email': 'no@example.com', 'password': 'Strong-password-123'})
        self.assertEqual(status, 400)
        invitation = self.admin.call('/api/invites', {'role': 'reviewer'})[1]
        reviewer = Client(self.base)
        self.register(reviewer, 'R', 'r@example.com', invitation['code'])
        second = Client(self.base)
        self.assertEqual(second.call('/api/register', {'name': 'R2', 'email': 'r2@example.com', 'password': 'Strong-password-123', 'invite_code': invitation['code']})[0], 403)
        self.assertEqual(reviewer.state()['user']['role'], 'reviewer')
        self.assertEqual(reviewer.call('/api/invites', {'role': 'admin'})[0], 403)
        self.assertEqual(reviewer.call('/api/backup')[0], 403)

    def test_csrf_origin_and_content_type(self):
        no_csrf = self.admin.call('/api/tasks', {'title': 'x', 'kind': 'material'}, headers={'X-CSRF-Token': ''})
        self.assertEqual(no_csrf[0], 403)
        self.assertEqual(self.admin.call('/api/logout', {}, headers={'Origin': 'https://evil.example'})[0], 403)
        self.assertEqual(self.admin.call('/api/logout', {}, headers={'Origin': self.base})[0], 200)
        self.assertEqual(self.guest.call('/api/login', raw=b'{}', headers={'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.guest.call('/api/login', raw=b'{}', headers={'Content-Encoding': 'gzip'})[0], 415)

    def test_invalid_json_and_fields_are_controlled(self):
        for body in (b'[]', b'null', b'{bad', b'{"a":NaN}', b'"hello"', b'{"a":Infinity}'):
            with self.subTest(body=body):
                self.assertEqual(self.admin.call('/api/tasks', raw=body)[0], 400)
        for patch in ({'title': []}, {'kind': {}}, {'url': 'javascript:alert(1)'}, {'url': 'https://me:pw@example.com/a'}, {'duration': '9:99'}, {'assignee': []}, {'tags': [None]}, {'priority': 'urgent'}):
            data = {'title': 'T', 'kind': 'aigc', **patch}
            with self.subTest(patch=patch):
                self.assertEqual(self.admin.call('/api/tasks', data)[0], 400)
        self.assertEqual(self.admin.call('/api/tasks/' + '9' * 5000, {})[0], 400)

    def test_independent_reviews_consensus_conflict_and_update(self):
        member = self.reviewer()
        tid = self.task()
        self.assertEqual(self.review(self.admin, tid)[1]['status'], '评测中')
        self.assertEqual(self.review(member, tid)[1]['status'], '已通过')
        self.assertEqual(self.review(member, tid, '退回')[1]['status'], '待复核')
        state = self.admin.state()
        self.assertEqual(len(state['reviews']), 2)
        self.assertEqual(state['reviews'][1]['issues'], ['闪烁'])
        self.assertEqual(self.review(self.admin, tid, '退回')[1]['status'], '已退回')
        self.assertEqual(len(self.admin.state()['reviews']), 2)

    def test_review_validation_and_missing_media(self):
        blank = self.task(url='')
        self.assertEqual(self.review(self.admin, blank)[0], 400)
        tid = self.task()
        for scores in ([True] * 5, [0] * 5, [6] * 5, [4] * 4, {}, ['4'] * 5):
            self.assertEqual(self.review(self.admin, tid, scores=scores)[0], 400)
        self.assertEqual(self.review(self.admin, tid, '退回', note='')[0], 400)
        self.assertEqual(self.review(self.admin, tid, '需复核', note='')[0], 400)
        self.assertEqual(self.review(self.admin, 9223372036854775808)[0], 400)
        self.assertEqual(self.review(self.admin, 9999)[0], 404)

    def test_task_ownership_edit_conflict_and_delete(self):
        member = self.reviewer()
        other = self.reviewer('Other', 'other@example.com')
        tid = self.task(member)
        task = next(t for t in member.state()['tasks'] if t['id'] == tid)
        self.assertEqual(other.call(f'/api/tasks/{tid}', {'title': '不允许'})[0], 403)
        self.assertEqual(member.call(f'/api/tasks/{tid}', {'title': '更新标题', 'expected_updated_at': task['updated_at']})[0], 200)
        self.assertEqual(member.call(f'/api/tasks/{tid}', {'title': '过期覆盖', 'expected_updated_at': task['updated_at']})[0], 409)
        self.assertEqual(self.review(member, tid)[0], 200)
        self.assertEqual(member.call(f'/api/tasks/{tid}', {'url': 'https://example.com/another.mp4'})[0], 409)
        self.assertEqual(other.call(f'/api/tasks/{tid}', {}, method='DELETE')[0], 403)
        self.assertEqual(self.admin.call(f'/api/tasks/{tid}', {}, method='DELETE')[0], 200)
        self.assertEqual(self.admin.state()['reviews'], [])

    def test_member_permissions_disable_and_last_admin(self):
        member = self.reviewer()
        uid = member.state()['user']['id']
        aid = self.admin.state()['user']['id']
        self.assertEqual(member.call('/api/members', {'user_id': uid, 'role': 'admin'})[0], 403)
        self.assertEqual(self.admin.call('/api/members', {'user_id': aid, 'role': 'reviewer'})[0], 409)
        self.assertEqual(self.admin.call('/api/members', {'user_id': uid, 'active': False})[0], 200)
        self.assertIsNone(member.state()['user'])
        self.assertEqual(member.call('/api/login', {'email': 'reviewer@example.com', 'password': 'Strong-password-123'})[0], 401)
        self.assertEqual(self.admin.call('/api/members', {'user_id': uid, 'active': 1})[0], 400)

    def test_rate_limit_persists_and_password_whitespace(self):
        wrong = Client(self.base)
        for _ in range(8):
            self.assertEqual(wrong.call('/api/login', {'email': 'missing@example.com', 'password': 'wrong'})[0], 401)
        self.assertEqual(wrong.call('/api/login', {'email': 'missing@example.com', 'password': 'wrong'})[0], 429)
        self.assertEqual(self.admin.call('/api/login', {'email': 'admin@example.com', 'password': ' Strong-password-123 '})[0], 401)
        self.assertEqual(self.admin.call('/api/login', {'email': 'admin@example.com', 'password': 'Strong-password-123'})[0], 200)

    def test_upload_content_auth_range_and_head(self):
        content = b'\x00\x00\x00\x20ftypisom\x00\x00\x00\x00isomavc1' + bytes(range(100))
        headers = {'Content-Type': 'video/mp4', 'X-Filename': '..%2F%3Cvideo%3E.mp4'}
        self.assertEqual(self.guest.call('/api/upload', raw=content, headers=headers)[0], 401)
        self.assertEqual(self.admin.call('/api/upload', raw=b'x' * 100, headers=headers)[0], 415)
        self.assertEqual(self.admin.call('/api/upload', raw=content, headers={'Content-Type': 'text/html'})[0], 415)
        status, uploaded, _ = self.admin.call('/api/upload', raw=content, headers=headers)
        self.assertEqual(status, 200, uploaded)
        self.assertNotIn('/', uploaded['name'])
        url = uploaded['url']
        self.assertEqual(self.guest.call(url)[0], 401)
        status, data, hdrs = self.admin.call(url)
        self.assertEqual((status, data), (200, content))
        status, data, hdrs = self.admin.call(url, headers={'Range': 'bytes=4-7'})
        self.assertEqual((status, data, hdrs['Content-Range']), (206, b'ftyp', f'bytes 4-7/{len(content)}'))
        self.assertEqual(self.admin.call(url, headers={'Range': 'bytes=-4'})[1], content[-4:])
        self.assertEqual(self.admin.call(url, headers={'Range': 'bytes=99999-'})[0], 416)
        self.assertEqual(self.admin.call(url, headers={'Range': 'bytes=1-2,4-6'})[0], 416)
        self.assertEqual(self.admin.call(url, headers={'Range': 'bytes=' + '9' * 5000 + '-'})[0], 416)
        status, body, hdrs = self.admin.call(url, method='HEAD')
        self.assertEqual((status, body, int(hdrs['Content-Length'])), (200, b'', len(content)))
        tid = self.task(url=url)
        self.assertEqual(self.review(self.admin, tid)[0], 200)
        self.assertEqual(list(app.MEDIA.glob('.upload-*')), [])

    def test_storage_quota_is_enforced(self):
        old_limit = app.STORAGE_LIMIT
        app.STORAGE_LIMIT = 32
        try:
            status, _, _ = self.admin.call('/api/upload', raw=b'\0\0\0 ftypisom' + b'0' * 100, headers={'Content-Type': 'video/mp4'})
            self.assertEqual(status, 507)
            self.assertEqual(list(app.MEDIA.iterdir()), [])
        finally:
            app.STORAGE_LIMIT = old_limit

    def test_adjudication_freezes_reviews_and_roundtrips(self):
        member = self.reviewer()
        tid = self.task()
        self.review(self.admin, tid)
        self.assertEqual(self.admin.call(f'/api/tasks/{tid}/resolve', {'verdict': '通过', 'note': '尚无独立复评'})[0], 400)
        self.review(member, tid, '退回')
        self.assertEqual(member.call(f'/api/tasks/{tid}/resolve', {'verdict': '通过', 'note': '裁定'})[0], 403)
        self.assertEqual(self.admin.call(f'/api/tasks/{tid}/resolve', {'verdict': '通过', 'note': ''})[0], 400)
        self.assertEqual(self.admin.call(f'/api/tasks/{tid}/resolve', {'verdict': '通过', 'note': '检查原始帧后确认可接受'})[0], 200)
        self.assertEqual(self.review(member, tid)[0], 409)
        backup = self.admin.call('/api/backup')[1]
        self.assertEqual(self.admin.call('/api/restore', {'backup': backup, 'mode': 'replace'})[0], 200)
        task = self.admin.state()['tasks'][0]
        self.assertEqual(task['status'], '已通过')
        self.assertEqual(task['resolution_note'], '检查原始帧后确认可接受')
        self.assertEqual(self.review(member, tid)[0], 409)

    def test_backup_privacy_atomic_restore_and_foreign_identities(self):
        member = self.reviewer()
        tid = self.task()
        self.review(member, tid)
        backup = self.admin.call('/api/backup')[1]
        encoded = json.dumps(backup)
        for secret in ('password', 'csrf', 'session', 'Strong-password'):
            self.assertNotIn(secret, encoded)
        self.assertFalse(backup['media_included'])
        for invalid in ({'status': []}, {'created_by': {}}, {'assignee': True}, {'resolution_verdict': '通过', 'resolution_by': None}, {'created_at': '<img src=x onerror=alert(1)>'}):
            corrupt = copy.deepcopy(backup)
            corrupt['tasks'][0].update(invalid)
            self.assertEqual(self.admin.call('/api/restore', {'backup': corrupt, 'mode': 'replace'})[0], 400)
            self.assertEqual(len(self.admin.state()['tasks']), 1)
        self.task(title='将被替换')
        self.assertEqual(self.admin.call('/api/restore', {'backup': backup, 'mode': 'replace'})[0], 200)
        self.assertEqual(len(self.admin.state()['tasks']), 1)
        foreign = copy.deepcopy(backup)
        foreign['workspace_id'] = 'foreign-workspace'
        foreign['users'][0]['role'] = 'admin'  # Never grants authentication.
        self.assertEqual(self.admin.call('/api/restore', {'backup': foreign, 'mode': 'replace'})[0], 200)
        state = self.admin.state()
        archived = [u for u in state['users'] if u['archived']]
        self.assertEqual(len(archived), 2)
        self.assertTrue(all(not u['active'] and u['role'] == 'reviewer' for u in archived))
        self.assertEqual(state['reviews'][0]['name'], 'Reviewer')
        self.assertEqual(state['user']['role'], 'admin')

    def test_audit_health_headers_and_static_paths(self):
        tid = self.task()
        events = self.admin.call('/api/audit')[1]['events']
        self.assertTrue(any(e['action'] == 'task.create' and e['target'] == str(tid) for e in events))
        self.assertEqual(self.guest.call('/api/audit')[0], 401)
        self.assertEqual(self.guest.call('/api/health')[1]['ok'], True)
        status, html, headers = self.guest.call('/')
        self.assertEqual(status, 200)
        self.assertIn(b'FrameFlow', html)
        self.assertEqual(headers['X-Frame-Options'], 'DENY')
        self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')
        self.assertEqual(self.guest.call('/%2e%2e/server.py')[0], 404)
        self.assertEqual(self.guest.call('/media/../../server.py')[0], 404)

    def test_concurrent_invitation_use_and_first_admin_invariant(self):
        invitation = self.admin.call('/api/invites', {'role': 'reviewer'})[1]['code']
        def use(number):
            client = Client(self.base)
            return client.call('/api/register', {'name': f'U{number}', 'email': f'u{number}@example.com', 'password': 'Strong-password-123', 'invite_code': invitation})[0]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            statuses = list(pool.map(use, range(3)))
        self.assertEqual(statuses.count(200), 1)
        self.assertEqual(statuses.count(403), 2)

    def test_request_too_large_rejected_before_read(self):
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        client.request('POST', '/api/login', body=None, headers={'Content-Type': 'application/json', 'Content-Length': str(app.MAX_JSON + 1)})
        response = client.getresponse()
        self.assertEqual(response.status, 413)
        response.read()
        client.close()


class MigrationTests(unittest.TestCase):
    def test_legacy_users_tasks_and_password_are_preserved(self):
        saved = app.DATA, app.DB, app.MEDIA
        with tempfile.TemporaryDirectory() as directory:
            try:
                app.DATA = Path(directory)
                app.DB, app.MEDIA = app.DATA / 'videoqa.db', app.DATA / 'media'
                salt = 'legacy-salt'
                legacy = salt + ':' + hashlib.pbkdf2_hmac('sha256', b'legacy-password', salt.encode(), 200000).hex()
                with sqlite3.connect(app.DB) as c:
                    c.executescript('CREATE TABLE users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,password TEXT);CREATE TABLE sessions(token TEXT PRIMARY KEY,user_id INTEGER,expires REAL);CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,kind TEXT,category TEXT,duration TEXT,status TEXT DEFAULT "待评测",created_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,url TEXT DEFAULT "",scene TEXT DEFAULT "nature");CREATE TABLE reviews(id INTEGER PRIMARY KEY,task_id INTEGER,user_id INTEGER,scores TEXT,note TEXT,verdict TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(task_id,user_id));')
                    c.execute('INSERT INTO users VALUES(1,?,?,?)', ('Legacy', 'legacy@example.com', legacy))
                    c.execute('INSERT INTO sessions VALUES(?,?,?)', ('plaintext-legacy-token', 1, time.time() + 10000))
                    c.execute('INSERT INTO tasks(id,title,kind,created_by) VALUES(1,?,?,1)', ('旧任务', 'aigc'))
                app.init()
                app.init()  # Migrations must be repeatable.
                with app.conn() as c:
                    user = c.execute('SELECT * FROM users').fetchone()
                    self.assertEqual(user['role'], 'admin')
                    self.assertTrue(app.password_ok('legacy-password', user['password']))
                    self.assertEqual(c.execute('SELECT count(*) FROM sessions').fetchone()[0], 0)
                    self.assertEqual(c.execute('SELECT title FROM tasks').fetchone()[0], '旧任务')
                    self.assertEqual(c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0], '2')
            finally:
                app.DATA, app.DB, app.MEDIA = saved


if __name__ == '__main__':
    unittest.main(verbosity=2)
