import tempfile,unittest,server,manage
from pathlib import Path
class RecoveryTests(unittest.TestCase):
 def test_reset_preserves_user_and_revokes_sessions(self):
  original=(server.DATA,server.DB,server.MEDIA)
  try:
   with tempfile.TemporaryDirectory() as d:
    server.DATA=Path(d);server.DB=Path(d)/'videoqa.db';server.MEDIA=Path(d)/'media';server.init()
    with server.conn() as c:
     uid=c.execute('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)',('Admin','admin@example.com',server.password_hash('original-password'),'admin')).lastrowid
     c.execute('INSERT INTO sessions(token,user_id,expires,csrf) VALUES(?,?,?,?)',('token',uid,9999999999,'csrf'))
    self.assertEqual(manage.reset_password('admin@example.com','replacement-password'),uid)
    with server.conn() as c:
     u=c.execute('SELECT * FROM users').fetchone();self.assertTrue(server.password_ok('replacement-password',u['password']));self.assertFalse(server.password_ok('original-password',u['password']));self.assertEqual(c.execute('SELECT count(*) FROM sessions').fetchone()[0],0);self.assertEqual(c.execute('SELECT action FROM audit').fetchone()[0],'auth.console_password_reset')
    with self.assertRaises(ValueError):manage.reset_password('admin@example.com','short')
    with self.assertRaises(ValueError):manage.reset_password('missing@example.com','replacement-password')
  finally:server.DATA,server.DB,server.MEDIA=original
if __name__=='__main__':unittest.main()
