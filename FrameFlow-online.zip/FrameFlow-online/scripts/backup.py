"""Consistent SQLite + media snapshot. Run with service stopped or uploads paused."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tarfile
import tempfile
from datetime import datetime, timezone


def backup(source, destination):
    source=Path(source).resolve();destination=Path(destination).resolve()
    if not source.is_dir() or not (source/'videoqa.db').is_file():
        raise ValueError('未找到 videoqa.db，请指定实际 VIDEOQA_DATA 目录')
    if destination.is_relative_to(source):
        raise ValueError('备份必须位于数据目录之外')
    if destination.exists():
        raise ValueError('目标已存在，拒绝覆盖现有备份')
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp)
        with sqlite3.connect(f'file:{source / "videoqa.db"}?mode=ro',uri=True) as src, sqlite3.connect(temp/'videoqa.db') as dst:
            src.backup(dst)
            if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise ValueError('数据库完整性检查失败')
        files=[]
        for p in source.rglob('*'):
            if p.is_symlink():
                raise ValueError('拒绝包含符号链接的数据目录')
            if p.is_file() and p.name not in {'videoqa.db','videoqa.db-wal','videoqa.db-shm','videoqa.db-journal'}:
                files.append(p)
        manifest={'format':'frameflow-server-snapshot-v1','created_at':datetime.now(timezone.utc).isoformat(),'files':{}}
        with tempfile.NamedTemporaryFile(prefix='.frameflow-backup-', dir=destination.parent) as out:
            with tarfile.open(fileobj=out,mode='w:gz') as archive:
                for p in [temp/'videoqa.db',*files]:
                    name='videoqa.db' if p.parent==temp else p.relative_to(source).as_posix()
                    digest=hashlib.sha256()
                    with p.open('rb') as f:
                        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
                    manifest['files'][name]=digest.hexdigest()
                    archive.add(p,arcname=name,recursive=False)
                (temp/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2))
                archive.add(temp/'snapshot-manifest.json',arcname='snapshot-manifest.json')
            out.flush()
            os.fsync(out.fileno())
            os.link(out.name,destination)
        os.chmod(destination,0o600)
    print(f'已保存完整快照：{destination}（数据库、账号、素材、会话；请保密存储）')


def restore(archive_path,destination):
    """Restore only into a new directory, never overwrite running server state."""
    destination=Path(destination).resolve()
    if destination.exists():raise ValueError('恢复目标必须不存在，防止覆盖正在使用的数据')
    with tempfile.TemporaryDirectory(dir=destination.parent) as temp:
        temp=Path(temp)
        with tarfile.open(archive_path,'r:gz') as archive:
            members=archive.getmembers()
            if len(members)>100000:raise ValueError('快照条目过多')
            if sum(m.size for m in members)>500*1024**3:raise ValueError('快照超过 500 GiB 限制')
            names=set()
            for m in members:
                if not m.isfile() or Path(m.name).is_absolute() or not (temp/m.name).resolve().is_relative_to(temp) or m.name in names:
                    raise ValueError('快照包含非法路径、重复文件或特殊条目')
                names.add(m.name)
            archive.extractall(temp,filter='data')
        manifest=json.loads((temp/'snapshot-manifest.json').read_text())
        if manifest.get('format')!='frameflow-server-snapshot-v1':raise ValueError('快照格式不兼容')
        if set(manifest['files'])!=names-{'snapshot-manifest.json'}:raise ValueError('快照清单不匹配')
        for name,expected in manifest['files'].items():
            digest=hashlib.sha256()
            with (temp/name).open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
            if digest.hexdigest()!=expected:raise ValueError('文件校验失败：'+name)
        with sqlite3.connect(temp/'videoqa.db') as c:
            if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('数据库损坏')
            # Invalidate restored sessions. Every member must log in again.
            if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sessions'").fetchone():c.execute('DELETE FROM sessions')
        os.rename(temp,destination)
        # TemporaryDirectory cleanup safely tolerates its renamed path.
    print(f'已恢复到新目录：{destination}；请配置 VIDEOQA_DATA 并以原服务用户设置权限后启动。')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='FrameFlow 全量数据快照/恢复（先停止应用写入）')
    parser.add_argument('action',choices=['backup','restore']);parser.add_argument('source');parser.add_argument('destination')
    args=parser.parse_args()
    try:
        (backup if args.action=='backup' else restore)(args.source,args.destination)
    except (ValueError,OSError,sqlite3.Error,tarfile.TarError,KeyError,json.JSONDecodeError) as error:
        parser.exit(1,str(error)+'\n')
