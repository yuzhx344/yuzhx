"""Package only reviewed sources; never include working databases or secrets."""
from pathlib import Path
import hashlib
import subprocess
import zipfile
ROOT=Path(__file__).resolve().parent
ART=ROOT/'artifacts'
def main():
    subprocess.run(['python3',str(ROOT/'build_offline.py')],cwd=ROOT,check=True)
    ART.mkdir(exist_ok=True)
    required=['server.py','manage.py','README.md','交付与使用手册.md','验收报告.md','Dockerfile','.dockerignore','.gitignore','smoke_test.py','tests_backend.py','tests_snapshot.py','tests_manage.py','qa_extra.py','qa_report.md','build_offline.py','offline_adapter.js','build_release.py']
    optional=['tests_ui.js','tests_offline.js','tests_acceptance.js','tests_accessibility.js','tests_deploy.py','artifacts/accessibility-results.json','artifacts/browser-results.json']
    files=[ROOT/p for p in required]+[ROOT/p for p in optional if (ROOT/p).is_file()]
    files += [p for folder in ['public','scripts','.github/workflows','tests/fixtures'] for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    files += [ROOT/'deploy'/name for name in ['compose.yaml','Caddyfile','.env.example']]
    for p in files:
        if p.is_symlink() or not p.is_file():raise ValueError(f'缺少交付文件：{p}')
    destination=ART/'FrameFlow-online.zip'
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(set(files)):
            archive.write(p,'FrameFlow-online/'+p.relative_to(ROOT).as_posix())
    outputs=[destination,ROOT/'offline'/'FrameFlow-offline.zip',ROOT/'offline'/'帧序-离线视频评测.html']
    (ART/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix() for p in outputs)+'\n')
    print('\n'.join(str(p.relative_to(ROOT))+'  '+str(p.stat().st_size)+' bytes' for p in outputs))
if __name__=='__main__':main()
